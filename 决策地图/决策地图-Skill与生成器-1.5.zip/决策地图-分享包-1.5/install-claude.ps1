#Requires -Version 7.0
[CmdletBinding(SupportsShouldProcess = $true)]
param([string]$SkillsDirectory = (Join-Path ([Environment]::GetFolderPath('UserProfile')) '.claude/skills'))
# Claude Code reads personal skills from ~/.claude/skills. Copying, per-file verification and refusal to overwrite are implemented once in install-codex.ps1 and reused here unchanged; -WhatIf is passed through.
$ErrorActionPreference = 'Stop'
$core = Join-Path $PSScriptRoot 'install-codex.ps1'
if (-not (Test-Path -LiteralPath $core)) { throw 'Extract the complete ZIP before installation.' }
& $core -SkillsDirectory $SkillsDirectory -WhatIf:$WhatIfPreference
