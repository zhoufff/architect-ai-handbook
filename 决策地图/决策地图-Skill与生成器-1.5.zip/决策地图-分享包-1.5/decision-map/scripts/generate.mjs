import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {loadNexus} from '../adapters/nexus.mjs';
import {loadStandard,MAP_FILE as STANDARD_MAP} from '../adapters/standard.mjs';
import {normalizeProject} from '../lib/project.mjs';
import {saveSnapshot,loadSnapshot} from '../lib/history.mjs';
import {renderPage} from '../lib/render-page.mjs';
import {loadArchifyArtifacts} from '../lib/archify-artifacts.mjs';
export const LAYOUTS=['standard','nexus'],NEXUS_MAP='.scratch/nexus-native-refactor/map.md';
export function detectLayout(root){const standard=fs.existsSync(path.join(root,STANDARD_MAP)),nexus=fs.existsSync(path.join(root,NEXUS_MAP));if(standard&&nexus)throw new Error('项目同时含有标准布局与 Nexus 布局的地图文件，请用 --layout 指定');if(standard)return 'standard';if(nexus)return 'nexus';throw new Error(`无法识别项目布局：${root} 下既没有 ${STANDARD_MAP} 也没有 ${NEXUS_MAP}`);}
function resolvedTarget(target){let existing=path.resolve(target);const suffix=[];while(!fs.existsSync(existing)){suffix.unshift(path.basename(existing));const parent=path.dirname(existing);if(parent===existing)throw new Error('找不到输出路径的已有父目录');existing=parent;}return path.join(fs.realpathSync(existing),...suffix);}
const realOrResolved=p=>fs.existsSync(p)?fs.realpathSync(p):path.resolve(p),inside=(parent,child)=>{const relative=path.relative(parent,child);return !relative||(relative!=='..'&&!relative.startsWith('..'+path.sep)&&!path.isAbsolute(relative));};
// Nothing may be written inside a protected directory (the map, every 决策卡/ directory, every linked source's directory) or onto an input file.
// The directory rule already covers every input file; the file rule is the ticket's second guard for adapters that declare a narrower list.
function protectSources(protectedDirs,inputFiles,targets){const dirs=protectedDirs.map(realOrResolved),files=inputFiles.map(realOrResolved);for(const target of targets){const resolved=resolvedTarget(target),dir=dirs.find(d=>inside(d,resolved));if(dir)throw new Error(`生成结果、回执与历史目录不能写入受保护的项目资料目录：${target}（受保护：${dir}）`);if(files.includes(resolved))throw new Error(`生成结果、回执与历史目录不能覆盖来源文件：${target}`);}}
export function generate({sourceRoot,dataPath,output,historyDirectory,diagramsPath,layout}){
  output=path.resolve(output);let loaded;
  if(dataPath){if(layout)throw new Error('--data 与 --layout 不能同时使用：展示数据不经过布局适配器');loaded=JSON.parse(fs.readFileSync(dataPath,'utf8'));layout='data';}
  else{const root=path.resolve(sourceRoot);layout ||= detectLayout(root);if(!LAYOUTS.includes(layout))throw new Error('未知布局：'+layout+'，可用 '+LAYOUTS.join('|'));loaded=layout==='standard'?loadStandard(root):loadNexus(root);}
  // protectedDirs is a write-protection list, not a project fact: keep it out of the snapshot data.
  const {protectedDirs,...input}=loaded,data=normalizeProject(input),inputFiles=(data.inputFiles||[]).map(f=>f.path);
  const protectedDirectories=protectedDirs||[...new Set(inputFiles.map(f=>path.dirname(f)))];
  const historyRoot=historyDirectory||path.join(path.dirname(output),'.decision-map-history',data.id);
  const receiptPath=path.join(path.dirname(output),path.basename(output,'.html')+'.生成记录.json'),candidate=output+'.candidate-'+process.pid;
  protectSources(protectedDirectories,inputFiles,[output,candidate,historyRoot,receiptPath]);
  const artifacts=diagramsPath?loadArchifyArtifacts(diagramsPath):{items:[],inputFiles:[]};
  const saved=saveSnapshot(data,historyRoot),versions=Object.fromEntries(saved.entries.map(e=>[e.id,normalizeProject(loadSnapshot(historyRoot,e.id))]));
  // Re-render stored facts with the current presentation code; never edit a snapshot.
  versions[saved.current.id]=data;
  const html=renderPage(data,saved.entries,versions,saved.current.id,artifacts.items);
  fs.mkdirSync(path.dirname(output),{recursive:true});fs.writeFileSync(candidate,html,{encoding:'utf8',flag:'wx'});fs.renameSync(candidate,output);
  const receipt={schemaVersion:1,packageVersion:'1.5',layout,output,project:data.id,generated:new Date().toISOString(),sourceRoot:sourceRoot?path.resolve(sourceRoot):null,protectedDirs:protectedDirectories.map(realOrResolved),cards:data.cards.length,confirmed:data.cards.filter(c=>c.status==='resolved').length,batchIds:data.batch.ids,sources:data.sources.length,inputFiles:data.inputFiles||[],diagramInputFiles:artifacts.inputFiles,diagrams:artifacts.items.map(({id,title,type,example})=>({id,title,type,example})),unresolvedLinks:data.unresolvedLinks||[],snapshot:saved.current,historyCount:saved.entries.length,createdSnapshot:saved.created,historyDirectory:historyRoot,artifactSha256:crypto.createHash('sha256').update(html).digest('hex'),upstreamCommit:'a07fa1d5b2a10cbea110c5a2be2817397a301cdc',verification:{data:'validated',nativeViewer:'included',nativeArtifacts:'validated-by-upstream',browser:'not-run'}};
  fs.writeFileSync(receiptPath,JSON.stringify(receipt,null,2));
  return receipt;
}
if(process.argv[1]&&fs.existsSync(process.argv[1])&&fs.realpathSync(process.argv[1])===fs.realpathSync(fileURLToPath(import.meta.url))){
  const usage='用法：node generate.mjs (--source 项目根目录 [--layout standard|nexus] | --data 展示数据.json) --output 地图.html [--history 历史目录] [--diagrams 原生图集.json]\n--source 未指定 --layout 时自动识别：存在 项目总览/md/决策地图.md 为 standard，存在 .scratch/nexus-native-refactor/map.md 为 nexus。';
  if(process.argv.length===3&&['--help','-h'].includes(process.argv[2]))console.log(usage);
  else{
    const options={},names={'--source':'sourceRoot','--data':'dataPath','--output':'output','--history':'historyDirectory','--diagrams':'diagramsPath','--layout':'layout'};
    for(let i=2;i<process.argv.length;i++){const key=names[process.argv[i]],value=process.argv[i+1];if(!key||!value||value.startsWith('--')||options[key])throw new Error(usage);options[key]=key==='layout'?value:path.resolve(value);i++;}
    if(!options.output||Boolean(options.sourceRoot)===Boolean(options.dataPath)||(options.layout&&(!options.sourceRoot||!LAYOUTS.includes(options.layout))))throw new Error(usage);
    console.log(JSON.stringify(generate(options),null,2));
  }
}
