# 原生 Archify 的统一入口

固定版本见 `../upstream-lock.json`。三页面中的地图可以同时装入决策图、五类原生图和原生架构比较。完整原生 CLI 由本包 `scripts/archify.mjs` 透明委托，保留参数、工作目录、输出及退出码；不是另一套删减实现。

## 把图加入同一个阅读页面

先按 `vendor/archify/SKILL.md` 选择类型并读取对应 schema/example，以项目资料编写类型化 JSON。自然语言和 Mermaid 由 Agent 理解语义后编写该 JSON；原生没有通用 Mermaid 解析器。

在资料旁维护图集清单，路径均相对清单文件；真实项目图使用 `example:false`，能力演示使用 `example:true`：

```json
{
  "version": 1,
  "items": [
    {"id":"system","title":"当前系统架构","type":"architecture","input":"architecture/current.json","example":false},
    {"id":"architecture-changes","title":"系统架构本次变化","type":"architecture-delta","before":"architecture/before.json","after":"architecture/current.json","example":false}
  ]
}
```

`type` 接受 `architecture/workflow/sequence/dataflow/lifecycle/architecture-delta`。`id` 稳定且唯一，不能使用保留字 `decision`。可选 `description` 解释材料范围，`quality` 为 `showcase`（默认）或 `standard`。架构项可选 `repoRoot`，需要真实 Git 根、origin 和规格中已存在的完整提交与来源；原生核验失败会终止生成，不能降级假冒 verified。

```powershell
node <Skill目录>/scripts/generate.mjs --source <Nexus项目目录> --diagrams <图集.json> --output <阅读页面.html>
node <Skill目录>/scripts/generate.mjs --data <其他项目展示数据.json> --diagrams <图集.json> --output <阅读页面.html>
```

生成器冻结输入字节，调用原生 deliver / compare，再核对输入和 HTML 指纹。页面嵌入完整 HTML 的桥接副本；“下载此图 HTML”保存原生独立产物，“材料与原生校验回执”保留原始规格与原生回执。示例不计入决策快照；架构比较的两份规格由清单明确指定，不能从一次图形生成推断旧版本。

## 原生生成工具能力

所有命令由 Agent 调用，用户只需提出任务。完整参数以以下入口的 help 和上游合同为准：

```powershell
node <Skill目录>/scripts/archify.mjs help
node <Skill目录>/scripts/archify.mjs guide "要表达的流程或结构" --json
node <Skill目录>/scripts/archify.mjs brands "产品名称" --json
node <Skill目录>/scripts/archify.mjs validate architecture <input.json> --quality showcase --json
node <Skill目录>/scripts/archify.mjs deliver architecture <input.json> <output.html> --quality showcase --json
node <Skill目录>/scripts/archify.mjs compare architecture <before.json> <after.json> <delta.html> --json
```

其余原生入口同样可用：`render`、`check`、`migrate workflow ... --to-schema 2`、`doctor`、`demo`、`preview`、`brands capture`、`visual-check`。具体条件：

- 新图采用各自原生 Schema；新 workflow 用 v2，旧 v1 通过迁移命令处理。
- 品牌是明确对象的身份。内置品牌本地查询；外部品牌 capture 只针对用户提供的官方 URL，采用内容指纹，不猜品牌或私自替换身份。
- `meta.locale` 支持 en / zh-CN，只影响原生固定控件，不翻译作者内容；主题、预设、品牌和显式图例按原生字段编写。
- `preview` 是用户需要主动预览时的文件更新工具，不默认后台启动；原生更新检查不会授权替换固定内核。
- `visual-check` 是浏览器工具，遵守当前环境的访问边界；发生访问拒绝时不能用它换渠道绕过。代码校验、浏览器行为和人工可读性分开记录。

## 地图页中的阅读能力

常规 Viewer 完整保留搜索、指针/键盘预览、节点与逐条关系、上下游、两点路径、角色比较、雷达、平移缩放、读取层级、章节/故事/跟随镜头、演示、有限动效、快捷键、深链接、品牌、图例和来源面板。

导出保留 PNG/JPEG/WebP/SVG/WebM、剪贴板 PNG、完整分享卡、路线/可达集合分享卡；外层另提供整套 HTML 和原生独立 HTML 下载。实际导出取决于浏览器支持，需要独立实测。

原生 architecture Delta 保留 Before / Delta / After、逐项变化、Review 巡览、移动影子和旧/新路线、SVG 与 Share Card 导出。原生 Delta 只有 Classic/Signal Flow/Blueprint 三预设；选择 Editorial 时桥接明确采用 Classic。五类常规图仍保留四预设。原生 Git 核验与 compare 当前只支持 architecture。

原生 SRC 支持固定提交、文件和行段；无 Git 的材料通过决策快照核对，不标为 Git verified。技术节点沿原生来源走，不能按同名 ID 误跳决策卡。

检查本次生成的 HTML 同级 `*.生成记录.json`、页面内原生回执，以及运行 `scripts/verify.mjs` 后产生的 `test-results/integration/` 记录。完整内核文件存在不等于当前图已通过检查，也不等于浏览器交互已验收。
