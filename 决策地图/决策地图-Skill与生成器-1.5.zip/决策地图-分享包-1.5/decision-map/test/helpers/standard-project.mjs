// Writes a clearly fictional project laid out per the 03 project-rule template (项目总览/md, 专题工作/*/决策卡).
// Used by tests only; nothing here is a real project record.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const write=(root,relative,body)=>{const file=path.join(root,relative);fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,body,'utf8');return file;};
const card=({title,date='2026-09-16',status='open',owner='示例业主',assignee='unassigned',type='decision',stage='探索期',blockedBy='none',extra='',sections})=>`# ${title}\n更新：${date}\nStatus: ${status}\nOwner: ${owner}\nAssignee: ${assignee}\nType: ${type}\nStage: ${stage}\nBlocked by: ${blockedBy}\n${extra}\n${sections}\n`;

export function writeStandardProject(root,{name='示例河畔书屋',topics=['场地与噪声','开放安排'],mapVersion='v1',batchStatus='已收敛',projectNameLine=true}={}){
  const [siteTopic,openingTopic]=topics;
  write(root,'AGENTS.md',`# ${name}\n\n## 项目身份\n\n${projectNameLine?`- 项目名称：${name}\n`:''}- 项目性质：虚构测试项目\n`);
  write(root,'README.md','# 虚构测试项目\n\n只用于测试 decision-map 的标准布局适配。\n');
  write(root,'项目总览/md/决策地图.md',`# ${name} 决策地图\n更新：2026-09-16 · ${mapVersion}\nPhase: 探索期\nBatch decisions: 01\nBatch status: ${batchStatus}\n\n## Decisions so far\n- [谁会使用这个空间](../../专题工作/${siteTopic}/决策卡/01-谁会使用.md)：示例：主要使用者为周边居民。\n\n## 当前下一步\n继续核对噪声来源（示例）。\n`);
  write(root,'项目总览/md/施工日志.md','# 施工日志\n\n- 当前阶段：探索期（示例）\n');
  write(root,`专题工作/${siteTopic}/专题索引.md`,`# ${siteTopic}（示例专题）\n\n- [01 谁会使用](决策卡/01-谁会使用.md)\n- [02 噪声来源](决策卡/02-噪声来源.md)\n`);
  write(root,`专题工作/${siteTopic}/噪声记录.md`,'# 噪声记录\n\n示例：白天临街噪声约 60 dB（虚构数字），细节见[测量报告](../../资料/测量报告.md)。\n');
  write(root,'资料/测量报告.md','# 测量报告\n\n示例：三次测量的虚构记录，只被噪声记录链接。\n');
  write(root,`专题工作/${siteTopic}/决策卡/01-谁会使用.md`,card({title:'谁会使用这个空间',status:'resolved',extra:'Knowledge: supported\nDecision: confirmed\nBatch section: 用户批准',sections:'## Question\n服务哪些人群？\n\n## Answer\n周边居民为主。\n\n## 用户批准\n选择周边居民为主要使用者（示例）。\n\n## 完成依据\n示例访谈记录。'}));
  write(root,`专题工作/${siteTopic}/决策卡/02-噪声来源.md`,card({title:'噪声来源是什么',type:'research',blockedBy:'01',extra:'Knowledge: assumed',sections:'## Question\n主要噪声来自哪里？见[噪声记录](../噪声记录.md)。\n\n## 已知输入\n一份虚构的现场记录。\n\n## 还需补充\n夜间测量。'}));
  write(root,`专题工作/${openingTopic}/决策卡/03-开放时段.md`,card({title:'开放时段怎样安排',status:'claimed',assignee:'agent',sections:'## Question\n每天开放多久？\n\n## 已确认的开放原则\n明确选择：**“工作日晚间开放（示例）”**'}));
  write(root,`专题工作/${openingTopic}/决策卡/04-回访安排.md`,card({title:'开放后怎样回访',sections:'## Question\n回访需要核对什么？\n\n## 后续处理\n待定。'}));
  return {root,map:path.join(root,'项目总览/md/决策地图.md'),cardsDir:topic=>path.join(root,'专题工作',topic,'决策卡')};
}

// Relative listing of every directory and every file with its content hash, for "nothing was written" assertions (catches empty directories and same-size overwrites).
export function tree(root){const rows=[];const walk=dir=>{for(const entry of fs.readdirSync(dir,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))){const file=path.join(dir,entry.name),relative=path.relative(root,file).replaceAll('\\','/');if(entry.isDirectory()){rows.push(relative+'/');walk(file);}else rows.push(relative+':'+crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'));}};walk(root);return rows;}
