import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import vm from 'node:vm';
import {normalizeProject} from '../lib/project.mjs';
import {renderDecisionMap,mapLayout} from '../lib/render-map.mjs';
import {generate} from '../scripts/generate.mjs';
import {loadSnapshot,compareSnapshots} from '../lib/history.mjs';
import {renderPage} from '../lib/render-page.mjs';
import {writeStandardProject,tree} from './helpers/standard-project.mjs';
const fixture=()=>JSON.parse(fs.readFileSync(new URL('../examples/community.json',import.meta.url),'utf8'));
const bundleFrom=html=>JSON.parse(html.match(/<script type="application\/json" id="bundle">([\s\S]*?)<\/script>/)[1]);
function directory(t){const d=fs.mkdtempSync(path.join(os.tmpdir(),'decision-integration-'));t.after(()=>fs.rmSync(d,{recursive:true,force:true}));return d;}

test('second project keeps its names, topology, independent lifecycle meanings and native viewer',()=>{
  const d=normalizeProject(fixture()),map=renderDecisionMap(d);
  assert.equal(map.counts.nodes,6);assert.equal(map.counts.edges,6);
  assert.match(map.html,/社区阅读空间/);assert.doesNotMatch(map.html,/NEXUS/);
  assert.equal(d.cards[0].implementationStatus,'not-started');assert.equal(d.cards[1].knowledgeStatus,undefined);
  assert.match(d.sources[1].html,/#page=source&amp;doc=map/);
  assert.doesNotMatch(map.svg,/data-node-kind="(?:backend|frontend|database)"/);
  for(const feature of ['Archify.focus','Archify.semanticLens','Archify.guidedViews','Archify.exportMenu','route-probe-copy','btn-overview-map','btn-present'])assert.ok(map.html.includes(feature),feature);
});

test('unsafe supplied HTML and script-closing text stay inert when raw Markdown is re-rendered',()=>{
  const d=fixture();d.name='</title><script>alert(1)</script>';d.sources[0].html='<script>UNTRUSTED_HTML</script>';d.sources[0].body+='\n<script>alert(2)</script>\n[bad](javascript:alert)';d.cards[0].questionHtml='<img src=x onerror=alert(1)>';
  const normalized=normalizeProject(d);assert.doesNotMatch(normalized.sources[0].html,/<script|javascript:|UNTRUSTED_HTML/);assert.doesNotMatch(normalized.cards[0].questionHtml,/<img/);
  const map=renderDecisionMap(normalized);assert.ok(!map.html.includes('</title><script>alert(1)</script>'));assert.match(normalized.sources[0].html,/&lt;script&gt;/);
});

test('invalid relations, duplicate sources and unsupported lifecycle states fail before generation',()=>{
  const d=fixture();d.cards[0].deps=['06'];assert.throws(()=>normalizeProject(d),/成环/);
  const e=fixture();e.sources.push({...e.sources[0]});assert.throws(()=>normalizeProject(e),/来源标识/);
  const f=fixture();f.cards[0].implementationStatus='probably-done';assert.throws(()=>normalizeProject(f),/生命周期/);
  const g=fixture();g.groups[0].id='"><script>';assert.throws(()=>normalizeProject(g),/主题/);
});

test('input reordering does not move nodes or reroute dependencies',()=>{
  const d=normalizeProject(fixture()),a=mapLayout(d);d.cards.reverse();const b=mapLayout(d);
  assert.deepEqual([...a.positions].sort(),[...b.positions].sort());assert.deepEqual(a.paths,b.paths);
});

test('pending batch issues remain unapproved; a closed batch needs explicit approval text',()=>{
  const pending=fixture();pending.batch.ids=['02'];assert.equal(normalizeProject(pending).cards[1].batchChoice,undefined);
  pending.batch.closed=true;assert.throws(()=>normalizeProject(pending),/明确批准/);
  const missing=fixture();missing.cards[1].batchChoice='选择A';assert.throws(()=>normalizeProject(missing),/批准原文/);
  missing.cards[1].parts=[{id:'approval',title:'用户批准',body:'虚构示例批准：选择A'}];missing.cards[1].batchSection='approval';missing.batch={ids:['02'],closed:true};assert.equal(normalizeProject(missing).batch.closed,true);
});

test('every generated destination is checked against protected source directories before any write; 项目总览/html is allowed',t=>{
  const dir=directory(t),root=path.join(dir,'project');writeStandardProject(root);const before=tree(root),cards=path.join(root,'专题工作/场地与噪声/决策卡');
  assert.throws(()=>generate({sourceRoot:root,output:path.join(cards,'a.html')}),/项目资料目录/);
  assert.throws(()=>generate({sourceRoot:root,output:path.join(root,'项目总览/md/决策地图.html')}),/项目资料目录/);
  assert.throws(()=>generate({sourceRoot:root,output:path.join(root,'专题工作/场地与噪声/地图.html')}),/项目资料目录/,'the directory of a linked source is protected');
  assert.throws(()=>generate({sourceRoot:root,output:path.join(root,'资料/地图.html')}),/项目资料目录/,'the directory of a transitively linked source is protected');
  assert.throws(()=>generate({sourceRoot:root,output:path.join(dir,'result.html'),historyDirectory:path.join(cards,'history')}),/项目资料目录/);
  assert.throws(()=>generate({sourceRoot:root,output:path.join(dir,'result.html'),historyDirectory:path.join(root,'项目总览/md/history/deeper')}),/项目资料目录/);
  assert.deepEqual(tree(root),before);assert.equal(fs.existsSync(path.join(dir,'result.html')),false);
  const receipt=generate({sourceRoot:root,output:path.join(root,'项目总览/html/决策地图.html')});
  assert.equal(receipt.layout,'standard');assert.ok(fs.existsSync(path.join(root,'项目总览/html/决策地图.html')));assert.ok(fs.existsSync(path.join(root,'项目总览/html/.decision-map-history',receipt.project,'index.json')));
  assert.deepEqual(tree(root).filter(row=>!row.startsWith('项目总览/html/')),before,'only 项目总览/html received writes');
  const beside=generate({sourceRoot:root,output:path.join(dir,'outside.html'),historyDirectory:path.join(dir,'history')});assert.equal(beside.snapshot.id,receipt.snapshot.id);
});

test('display data with real input files protects those files and their directories',t=>{
  const dir=directory(t),docs=path.join(dir,'docs');fs.mkdirSync(docs);const note=path.join(docs,'note.md');fs.writeFileSync(note,'# note\n');
  const data=fixture();data.inputFiles=[{path:note.replaceAll('\\','/'),hash:'unchecked-here'}];const dataPath=path.join(dir,'fixture.json');fs.writeFileSync(dataPath,JSON.stringify(data));
  assert.throws(()=>generate({dataPath,output:note}),/项目资料目录/,'an input file is inside a protected directory, so the directory rule fires first');assert.throws(()=>generate({dataPath,output:path.join(docs,'map.html')}),/项目资料目录/);assert.throws(()=>generate({dataPath,layout:'standard',output:path.join(dir,'map.html')}),/--layout/);assert.throws(()=>generate({dataPath,output:path.join(dir,'map.html'),historyDirectory:docs}),/项目资料目录/);
  assert.deepEqual(fs.readdirSync(docs),['note.md']);assert.equal(fs.readFileSync(note,'utf8'),'# note\n');
  const receipt=generate({dataPath,output:path.join(dir,'map.html')});assert.equal(receipt.layout,'data');assert.deepEqual(receipt.protectedDirs,[fs.realpathSync(docs)]);
});

test('the nexus layout still generates, and only its own source directories are protected',t=>{
  const dir=directory(t),root=path.join(dir,'nexus-like'),effort=path.join(root,'.scratch/nexus-native-refactor');fs.mkdirSync(path.join(effort,'issues'),{recursive:true});
  fs.writeFileSync(path.join(effort,'map.md'),'# 虚构 Nexus 地图\n更新：2026-09-16 · v9\nPhase: 测试\nBatch status: 进行中\n\n## Decisions so far\n\n## 当前下一步\n虚构的下一步。\n');
  fs.writeFileSync(path.join(effort,'issues/01-test.md'),'# 虚构问题\n更新：2026-09-16\nStatus: open\nOwner: 测试\nAssignee: unassigned\nType: research\nStage: 测试\nBlocked by: none\n\n## Question\n虚构问题原文。\n');
  const before=tree(root);
  assert.throws(()=>generate({sourceRoot:root,output:path.join(effort,'issues/map.html')}),/项目资料目录/);
  assert.throws(()=>generate({sourceRoot:root,output:path.join(dir,'out.html'),historyDirectory:path.join(effort,'history')}),/项目资料目录/);
  assert.deepEqual(tree(root),before);assert.equal(fs.existsSync(path.join(dir,'out.html')),false);
  const receipt=generate({sourceRoot:root,output:path.join(root,'项目总览/html/决策地图.html')});
  assert.equal(receipt.layout,'nexus');assert.equal(receipt.project,'nexus');assert.equal(receipt.cards,1);
  assert.deepEqual(receipt.protectedDirs.map(p=>path.relative(root,p).replaceAll('\\','/')).sort(),['.scratch/nexus-native-refactor','.scratch/nexus-native-refactor/issues'],'the project root itself is no longer protected');
});

test('an output path that reaches a protected directory through a link is refused',t=>{
  const dir=directory(t),root=path.join(dir,'project');writeStandardProject(root);const cards=path.join(root,'专题工作/开放安排/决策卡'),link=path.join(dir,'link');
  fs.symlinkSync(cards,link,process.platform==='win32'?'junction':'dir');const before=tree(root);
  assert.throws(()=>generate({sourceRoot:root,output:path.join(link,'a.html')}),/项目资料目录/);
  assert.throws(()=>generate({sourceRoot:root,output:path.join(dir,'out.html'),historyDirectory:path.join(link,'history')}),/项目资料目录|符号链接/);
  assert.deepEqual(tree(root),before);assert.equal(fs.existsSync(path.join(dir,'out.html')),false);
});

test('three reading pages and nested records render safely; a pending batch is not shown as approved',()=>{
  const d=fixture();d.batch.ids=['02'];d.phase='<img src=x onerror=alert(1)>';const data=normalizeProject(d),html=renderPage(data,[{id:'one',createdAt:'2026-09-13T00:00:00Z',mapVersion:'v1'}],{one:data},'one'),bundle=bundleFrom(html),script=html.match(/<script>([\s\S]*?)<\/script>/)[1];
  for(const fragment of ['page=overview','page=list','page=graph','page=decision&id=02','page=source&doc=card-02','page=sources']){
    const app={innerHTML:''},dataset={textContent:JSON.stringify(data)},embedded={textContent:JSON.stringify(bundle)},location={hash:'#'+fragment,href:'https://example.invalid/#'+fragment};
    const context={URLSearchParams,console,location,history:{state:null,replaceState(state){this.state=state;}},document:{getElementById:id=>id==='dataset'?dataset:id==='bundle'?embedded:id==='app'?app:null,documentElement:{dataset:{theme:'dark',preset:'blueprint'}},body:{classList:{toggle(){}}},querySelectorAll:()=>[],addEventListener(){}},window:{addEventListener(){}},localStorage:{getItem:()=>null},requestAnimationFrame(){},setTimeout(){},clearTimeout(){}};
    vm.runInNewContext(script,context);assert.match(app.innerHTML,/主要导航/);assert.doesNotMatch(app.innerHTML,/<img src=x|undefined|NaN/);
    if(fragment==='page=overview'){assert.doesNotMatch(app.innerHTML,/本批已确认|这项选择已定/);assert.match(app.innerHTML,/本批尚无附带批准原文/);}
    if(fragment==='page=graph'){assert.match(app.innerHTML,/首次保存的真实基线/);assert.match(app.innerHTML,/id="native-map"/);}
    if(fragment==='page=decision&id=02')assert.match(app.innerHTML,/focus|在关系图中定位/);
  }
});

test('generation reuses factual baseline but refreshes presentation; later evidence creates a comparison',t=>{
  const dir=directory(t),dataFile=path.join(dir,'data.json'),output=path.join(dir,'sample.html');const d=fixture();
  fs.writeFileSync(dataFile,JSON.stringify(d));const first=generate({dataPath:dataFile,output});
  const snapshotFile=path.join(first.historyDirectory,first.snapshot.id+'.json'),original=fs.readFileSync(snapshotFile);
  d.groups[0].title='使用对象与开放安排';d.mapViews=[{id:'audit',label:'本次查证',focus:['d03','d04'],note:'虚构示例章节'}];
  fs.writeFileSync(dataFile,JSON.stringify(d));const same=generate({dataPath:dataFile,output}),firstHtml=fs.readFileSync(output,'utf8'),firstBundle=bundleFrom(firstHtml);
  assert.equal(same.createdSnapshot,false);assert.equal(same.historyCount,1);assert.equal(same.snapshot.id,first.snapshot.id);
  assert.equal(firstBundle.versions[same.snapshot.id].groups[0].title,d.groups[0].title);assert.equal(firstBundle.frames[same.snapshot.id].views[0].id,'audit');assert.deepEqual(fs.readFileSync(snapshotFile),original);
  d.mapVersion='示例 v2';d.cards[2].knowledgeStatus='supported';d.cards[2].summary='虚构示例：补入一份现场记录，仍需复核。';d.sources[3].body+='\n\n第二次示例记录：补入一份虚构现场记录，尚未获得施工批准。';
  fs.writeFileSync(dataFile,JSON.stringify(d));const second=generate({dataPath:dataFile,output}),html=fs.readFileSync(output,'utf8'),bundle=bundleFrom(html);
  assert.equal(second.historyCount,2);assert.equal(second.createdSnapshot,true);assert.equal(Object.keys(bundle.frames).length,2);
  const delta=bundle.deltas[first.snapshot.id+'~'+second.snapshot.id];assert.equal(delta.hasChanges,true);assert.ok(delta.changed.some(c=>c.id==='03'&&c.fields.includes('knowledgeStatus')));assert.ok(delta.evidenceChanged.some(c=>c.id==='03'));
  assert.equal(loadSnapshot(first.historyDirectory,first.snapshot.id).cards[2].knowledgeStatus,'unknown');assert.deepEqual(fs.readFileSync(snapshotFile),original);
  assert.equal(compareSnapshots(normalizeProject(d),bundle.versions[second.snapshot.id]).hasChanges,false);
  assert.doesNotMatch(html,/<script[^>]*src=|<link[^>]*rel="stylesheet"/i);for(const script of html.matchAll(/<script>([\s\S]*?)<\/script>/g))new Function(script[1]);
});
