import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {renderDecisionMap,mapLayout} from '../lib/render-map.mjs';
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
if(process.argv.length!==3)throw new Error('用法：node verify.mjs <待校验的HTML路径>');
const output=path.resolve(process.argv[2]);
const html=fs.readFileSync(output,'utf8'),data=JSON.parse(html.match(/<script type="application\/json" id="dataset">([\s\S]*?)<\/script>/)[1]),bundle=JSON.parse(html.match(/<script type="application\/json" id="bundle">([\s\S]*?)<\/script>/)[1]);
assert.ok(bundle.versions[bundle.currentId]);assert.equal(Object.keys(bundle.frames).length,bundle.entries.length);assert.ok(bundle.viewerTemplate.includes('var Archify = {}'));assert.ok(!/<script[^>]*src=|<link[^>]*rel="stylesheet"/i.test(html));
for(const capability of ['Archify.focus','Archify.semanticLens','Archify.view','Archify.exportMenu','Archify.guidedViews','route-probe-copy','btn-overview-map','btn-preset','btn-theme','btn-present'])assert.ok(bundle.viewerTemplate.includes(capability),'Missing '+capability);
const locks=JSON.parse(fs.readFileSync(path.join(root,'upstream-lock.json'),'utf8'));for(const [name,hash]of Object.entries(locks.files)){assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'vendor/archify',name))).digest('hex'),hash,'Upstream modified: '+name);}
const allScripts=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m=>m[1]);allScripts.forEach(s=>new Function(s));
const sourceInputs=data.inputFiles||[];for(const file of sourceInputs)assert.equal(crypto.createHash('sha256').update(fs.readFileSync(file.path)).digest('hex'),file.hash,'Source changed after generation');
const layout=mapLayout(data),rects=[...layout.positions.entries()],crossings=[];
for(const [id,a] of rects)for(const [other,b]of rects)if(id<other)assert.ok(!(a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y),'Nodes overlap');
for(const edge of layout.paths)for(let i=1;i<edge.points.length;i++){const [x1,y1]=edge.points[i-1],[x2,y2]=edge.points[i];for(const [id,p]of rects){if(id===edge.from||id===edge.to)continue;const hit=x1===x2?x1>p.x&&x1<p.x+p.w&&Math.max(y1,y2)>p.y&&Math.min(y1,y2)<p.y+p.h:y1>p.y&&y1<p.y+p.h&&Math.max(x1,x2)>p.x&&Math.min(x1,x2)<p.x+p.w;if(hit)crossings.push([edge.id,id]);}}
assert.deepEqual(crossings,[]);const map=renderDecisionMap(data);assert.equal((map.svg.match(/data-decision-id=/g)||[]).length,data.cards.length);assert.equal((map.svg.match(/data-edge-from=/g)||[]).length,data.cards.reduce((n,c)=>n+c.deps.length,0));
assert.ok(!/data-node-kind="(?:frontend|backend|database)"/.test(map.svg));
const artifactIds=new Set();for(const artifact of bundle.artifacts||[]){assert.ok(!artifactIds.has(artifact.id)&&artifact.id.toLowerCase()!=='decision');artifactIds.add(artifact.id);assert.equal(artifact.receipt.ok,true);assert.equal(artifact.receipt.validation.checksPassed,artifact.receipt.validation.checkCount);assert.equal(crypto.createHash('sha256').update(artifact.html).digest('hex'),artifact.receipt.artifact.sha256);assert.ok(artifact.embeddedHtml.includes('decision-map-viewer-v1'));assert.ok(!/<script[^>]*src=|<link[^>]*rel="stylesheet"/i.test(artifact.html));for(const source of artifact.sourceSpecs)assert.equal(crypto.createHash('sha256').update(source.body).digest('hex'),source.hash);}
const receiptPath=path.join(path.dirname(output),path.basename(output,'.html')+'.生成记录.json');let diagramInputs=[];if(fs.existsSync(receiptPath)){diagramInputs=JSON.parse(fs.readFileSync(receiptPath,'utf8')).diagramInputFiles||[];for(const source of diagramInputs)assert.equal(crypto.createHash('sha256').update(fs.readFileSync(source.path)).digest('hex'),source.hash);}
const out=path.join(root,'test-results/integration');fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'native-'+data.id+'.html'),map.html);
const result={output,cards:data.cards.length,relations:layout.paths.length,histories:bundle.entries.length,upstreamFilesUnchanged:Object.keys(locks.files).length,originalSourcesUnchanged:sourceInputs.length,nativeArtifacts:artifactIds.size,nativeArtifactChecks:(bundle.artifacts||[]).reduce((count,a)=>count+a.receipt.validation.checkCount,0),nativeInputFilesUnchanged:diagramInputs.length,routesThroughNodes:0,nativeViewerIncluded:true,standalone:true,browser:'not-run'};
fs.writeFileSync(path.join(out,data.id+'-integration-checks.json'),JSON.stringify(result,null,2));if(data.id==='nexus')fs.writeFileSync(path.join(out,'integration-checks.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
