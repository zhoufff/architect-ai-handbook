#Requires -Version 7.0
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$nodeCommand = Get-Command node -ErrorAction SilentlyContinue
if (-not $nodeCommand) { throw 'Node.js 18 or later is required. Ask Codex to locate an existing Node.js runtime first.' }
$nodeExecutable = $nodeCommand.Source
$nodeMajor = & $nodeExecutable -p 'parseInt(process.versions.node)'
if ($LASTEXITCODE -ne 0 -or [int]$nodeMajor -lt 18) { throw 'Node.js 18 or later is required.' }
& $nodeExecutable (Join-Path $PSScriptRoot 'decision-map/scripts/build-example.mjs') --gallery
if ($LASTEXITCODE -ne 0) { throw 'Demo generation failed.' }
$output = Join-Path $PSScriptRoot ([string]::Concat([char]0x590D,[char]0x7528,[char]0x793A,[char]0x4F8B,'.html'))
& $nodeExecutable (Join-Path $PSScriptRoot 'decision-map/scripts/verify.mjs') $output
if ($LASTEXITCODE -ne 0) { throw 'Demo validation failed.' }
Write-Output "Open in your browser: $output"
