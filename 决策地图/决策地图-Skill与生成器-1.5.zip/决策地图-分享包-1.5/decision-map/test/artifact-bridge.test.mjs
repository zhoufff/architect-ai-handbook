import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { loadArchifyArtifacts } from '../lib/archify-artifacts.mjs';
import vm from 'node:vm';
import { embedArtifact } from '../lib/embed-artifact.mjs';

const source = readFileSync(new URL('../assets/artifact-bridge.js', import.meta.url), 'utf8');
function harness(kind = 'diagram', snapshotTab = null) {
  const listeners = {};
  const sent = [];
  const root = { dataset: { theme: 'dark', preset: 'classic' } };
  const parent = { postMessage: value => sent.push(value) };
  const location = { href: 'blob:https://example.test/id', hash: '' };
  const tabs = ['base', 'delta', 'head'].map(target => ({ dataset: { target }, selected: target === 'delta', getAttribute() { return String(this.selected); }, click() { tabs.forEach(tab => { tab.selected = tab === this; }); } }));
  const rows = ['component:a', 'component:a["#&?]/中文'].map(changeKey => ({ dataset: { changeKey }, active: false, getAttribute() { return this.active ? 'step' : null; }, click() { rows.forEach(row => { row.active = row === this; }); tabs[1].click(); } }));
  const document = { documentElement: root, querySelectorAll(selector) { return selector === '[data-target]' ? tabs : selector === '[data-change-key]' ? rows : []; }, querySelector() { return { click() { rows.forEach(row => { row.active = false; }); tabs[1].click(); } }; } };
  const history = { replaceState(_a, _b, url) { if (!url.startsWith('blob:')) throw Error('Broken blob path'); location.href = url; location.hash = new URL(url).hash; }, pushState(...args) { this.replaceState(...args); } };
  const window = { __decisionMapArtifact: { id: 'test', kind, snapshotTab }, parent, addEventListener(type, fn) { (listeners[type] ||= []).push(fn); }, dispatchEvent(event) { (listeners[event.type] || []).forEach(fn => fn(event)); }, Archify: { theme: { toggle() { root.dataset.theme = root.dataset.theme === 'dark' ? 'light' : 'dark'; } }, preset: { apply(value) { root.dataset.preset = value; } } } };
  vm.runInNewContext(source, { window, document, location, history, URL, URLSearchParams, Event, queueMicrotask, MutationObserver: class { observe() {} } });
  const receive = data => window.dispatchEvent({ type: 'message', source: parent, data: { namespace: 'decision-map-viewer-v1', diagram: 'test', ...data } });
  window.dispatchEvent(new Event('DOMContentLoaded'));
  return { window, location, history, root, rows, tabs, sent, receive };
}
const configure = { type: 'configure', parentUrl: 'https://example.test/map.html?before=old&comparison=old&decision=old#decision=stale', fragment: 'focus=api', theme: 'light', preset: 'editorial' };

test('native hash updates, focus and all copied native links stay on the host map', async () => {
  const h = harness();
  assert.equal(h.sent[0].type, 'ready');
  h.receive(configure);
  assert.equal(h.location.hash, '#focus=api');
  assert.equal(h.root.dataset.theme, 'light');
  assert.equal(h.root.dataset.preset, 'editorial');
  for (const fragment of ['focus=a%26b', 'route=a~b', 'lens=security~cost', 'view=overview&beat=api']) {
    h.history.replaceState(null, '', 'https://example.test/id#' + fragment);
    const url = new URL(h.window.DecisionMapArtifact.share(h.location.href));
    assert.equal(url.protocol, 'https:');
    assert.equal(url.pathname, '/map.html');
    assert.equal(url.search, '');
    const params = new URLSearchParams(url.hash.slice(1));
    assert.equal(params.get('diagram'), 'test');
    assert.equal(params.get('map'), fragment);
    assert.equal(params.has('decision'), false);
  }
  h.receive({ type: 'focus', fragment: 'focus=other' });
  assert.equal(h.location.hash, '#focus=other');
  await Promise.resolve();
  assert.equal(h.sent.at(-1).fragment, 'focus=other');
  assert.equal(h.sent.some(message => message.type === 'open-record'), false);
});

test('Delta restores exact stable keys and snapshot tabs, with declared preset compatibility', () => {
  const h = harness('architecture-delta');
  const key = h.rows[1].dataset.changeKey;
  h.receive({ ...configure, fragment: new URLSearchParams({ tab: 'head', change: key, native: 'focus=api' }).toString() });
  assert.equal(h.rows[0].active, false);
  assert.equal(h.rows[1].active, true);
  assert.equal(h.tabs[2].selected, true);
  assert.equal(h.root.dataset.preset, 'classic');
  assert.equal(new URLSearchParams(h.sent.at(-1).fragment).get('change'), key);
  assert.equal(new URLSearchParams(h.sent.at(-1).fragment).get('native'), 'focus=api');
  h.receive({ type: 'focus', fragment: 'tab=delta&change=missing' });
  assert.equal(h.rows.some(row => row.active), false);
});

test('nested snapshots share their own Before/After selection and native focus', () => {
  for (const tab of ['base', 'head']) {
    const h = harness('diagram', tab);
    h.receive({ ...configure, change: 'component:x' });
    const url = new URL(h.window.DecisionMapArtifact.share('about:srcdoc#route=a~b'));
    const map = new URLSearchParams(new URLSearchParams(url.hash.slice(1)).get('map'));
    assert.equal(map.get('tab'), tab);
    assert.equal(map.get('native'), 'route=a~b');
    assert.equal(map.get('change'), 'component:x');
  }
});

test('derived native HTML keeps original item/vendor intact and bridges both encoded snapshots', () => {
  const path = new URL('../vendor/archify/assets/template.html', import.meta.url);
  const html = readFileSync(path, 'utf8');
  const item = Object.freeze({ id: 'test', kind: 'diagram', html });
  const derived = embedArtifact(item);
  assert.equal(item.html, html);
  assert.equal(readFileSync(path, 'utf8'), html);
  assert.match(derived, /DecisionMapArtifact\.share\(value\)/);
  assert.doesNotMatch(derived, /location\.pathname \+ location\.search/);
  assert.match(derived, /Archify\.sourceEvidence/);
  const nested = '<html><head></head><body><script>history.replaceState(null, "", location.pathname + location.search + "#focus=a");</script></body></html>';
  const escaped = nested.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const delta = embedArtifact({ id: 'test', kind: 'architecture-delta', html: '<html><head></head><body><iframe class="snapshot-frame" srcdoc="' + escaped + '"></iframe><iframe class="snapshot-frame" srcdoc="' + escaped + '"></iframe></body></html>' });
  assert.match(delta, /&quot;snapshotTab&quot;:&quot;base&quot;/);
  assert.match(delta, /&quot;snapshotTab&quot;:&quot;head&quot;/);
  assert.doesNotMatch(delta, /location\.pathname \+ location\.search/);
});

test('generated Delta keeps canonical SVG and receipt unchanged; nested executable scripts compile', () => {
  const item = loadArchifyArtifacts(fileURLToPath(new URL('../examples/archify-gallery.json', import.meta.url))).items.find(item => item.type === 'architecture-delta');
  const html = item.html;
  const derived = embedArtifact(Object.freeze({ id: 'compare', kind: 'architecture-delta', html }));
  const receipt = /<script[^>]*id="archify-compare-receipt"[^>]*>[\s\S]*?<\/script>/.exec(html)?.[0];
  assert.ok(receipt);
  assert.ok(derived.includes(receipt));
  const svg = /<svg\b[\s\S]*?<\/svg>/.exec(html)?.[0];
  assert.ok(svg);
  assert.ok(derived.includes(svg));
  const decode = value => value.replace(/&(quot|#39|lt|gt|amp);/g, (_, key) => ({ quot: '"', '#39': "'", lt: '<', gt: '>', amp: '&' })[key]);
  const nested = [...derived.matchAll(/<iframe\b[^>]*\bsrcdoc="([\s\S]*?)"/g)].map(match => decode(match[1]));
  assert.equal(nested.length, 2);
  let scriptCount = 0;
  for (const document of [derived, ...nested]) {
    assert.doesNotMatch(document, /location\.pathname \+ location\.search/);
    for (const match of document.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/g)) {
      if (/application\/json/.test(match[1])) continue;
      new vm.Script(match[2]);
      scriptCount++;
    }
  }
  assert.ok(scriptCount >= 6);
  assert.equal(item.html, html);
});
