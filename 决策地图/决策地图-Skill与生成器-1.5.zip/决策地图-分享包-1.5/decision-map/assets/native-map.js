// One map page hosts the decision viewer, the five native renderers and native Delta.
let activeMapUrl='';
const viewerNamespace='decision-map-viewer-v1';
const diagramTypeLabels={architecture:'架构图',workflow:'流程图',sequence:'时序图',dataflow:'数据流图',lifecycle:'状态图','architecture-delta':'架构变化'};
const diagramLocations={};
function activeRevision(){return state.revision||B.currentId;}
function beforeRevision(){return state.before||B.entries.filter(e=>e.id!==activeRevision()).at(-1)?.id||'';}
function effectiveRevision(){return state.comparison==='before'&&beforeRevision()?beforeRevision():activeRevision();}
function activeArtifact(){return (B.artifacts||[]).find(a=>a.id===state.diagram)||null;}
function appearance(){return{theme:document.documentElement.dataset.theme||'dark',preset:document.documentElement.dataset.preset||'blueprint'};}
function setAppearance(theme,preset){
  if(['dark','light'].includes(theme))document.documentElement.dataset.theme=theme;
  if(['classic','signal-flow','blueprint','editorial'].includes(preset))document.documentElement.dataset.preset=preset;
  try{localStorage.setItem('decision-map-appearance',JSON.stringify(appearance()));}catch{}
  const select=document.getElementById('appearance-preset');if(select)select.value=appearance().preset;
  const button=document.getElementById('appearance-theme');if(button)button.textContent=appearance().theme==='dark'?'浅色':'深色';
}
function configureViewer(){
  const frame=document.getElementById('native-map');
  if(frame)frame.contentWindow.postMessage({namespace:viewerNamespace,type:'configure',parentUrl:location.href,diagram:state.diagram||'decision',revision:effectiveRevision(),fragment:mapFragment(),...appearance()},'*');
}
function comparisonData(){return B.deltas[beforeRevision()+'~'+activeRevision()]||null;}
function comparisonFrame(){return B.comparisonFrames?.[beforeRevision()+'~'+activeRevision()]||null;}
function mapFragment(){if(state.map)return state.map;if(state.id&&!activeArtifact()){const params=new URLSearchParams({focus:'d'+state.id});if(['upstream','downstream'].includes(state.mode))params.set('reach',state.mode);return params.toString();}return '';}
function graphPicker(){
  const artifacts=B.artifacts||[],option=a=>`<option value="${esc(a.id)}"${state.diagram===a.id?' selected':''}>${esc(diagramTypeLabels[a.type]||a.type)} · ${esc(a.title)}</option>`;
  return `<section class="graph-picker" aria-label="选择要阅读的地图"><label for="diagram-select">查看地图</label><select id="diagram-select"><optgroup label="项目记录"><option value="decision"${!activeArtifact()?' selected':''}>决策地图 · ${esc(D.name)}</option>${artifacts.filter(a=>!a.example).map(option).join('')}</optgroup>${artifacts.some(a=>a.example)?`<optgroup label="Archify 官方示例 · 非项目事实">${artifacts.filter(a=>a.example).map(option).join('')}</optgroup>`:''}</select><button type="button" class="button" id="save-reading-package">保存整套页面</button></section>`;
}
function graph(){return graphPicker()+(activeArtifact()?artifactGraph(activeArtifact()):decisionGraph());}
function decisionGraph(){
  const hasBefore=Boolean(beforeRevision()),delta=comparisonData(),entry=B.entries.find(e=>e.id===activeRevision());
  return `<div class="map-context"><div><span class="number-label">关系与版本</span><strong>${esc(D.name)}</strong><small>${esc(D.mapVersion)} · ${D.cards.length} 个问题</small></div><div class="comparison-controls"><label>对比基线 <select id="before-select"${hasBefore?'':' disabled'}>${hasBefore?B.entries.filter(e=>e.id!==activeRevision()).map(e=>`<option value="${e.id}"${e.id===beforeRevision()?' selected':''}>${esc(e.mapVersion||e.id.slice(0,8))} · ${esc(e.createdAt.slice(0,16).replace('T',' '))}</option>`).join(''):'<option>首次基线</option>'}</select></label><div class="comparison-tabs">${[['before','Before'],['delta','Delta'],['after','After']].map(([id,label])=>`<button data-comparison="${id}" aria-pressed="${state.comparison===id}"${!hasBefore&&id!=='after'?' disabled':''}>${label}</button>`).join('')}</div></div></div>${!hasBefore?'<p class="baseline-note">首次保存的真实基线。以后决策资料发生变化时，这里会显示前后版本与变化；本次样式更新不计作决策变化。</p>':`<p class="baseline-note">${state.comparison==='before'?'正在查看对比基线。':state.comparison==='delta'?'展示前后并集：新增关系为实线，已移除关系为虚线；它们不代表同一时刻的依赖。'+(comparisonFrame()?.cyclic?' 前后依赖方向发生变化，并集按编号排列，不表示项目阶段。':''):'正在查看所选版本。'} 新增 ${delta?.added.length||0} · 移除 ${delta?.removed.length||0} · 改变 ${delta?.changed.length||0} · 依据变化 ${delta?.evidenceChanged.length||0}</p>`}${hasBefore&&state.comparison==='delta'?`<div id="decision-review-slot">${decisionReviewBar()}</div>`:''}<iframe id="native-map" title="Archify 决策地图" allow="clipboard-write; fullscreen"></iframe>${hasBefore&&state.comparison==='delta'?changeList(delta):''}<p class="map-footer">节点和关系来自保存的原文；“核对记录依据”在本页打开。版本生成于 ${esc(entry.createdAt.replace('T',' ').slice(0,19))}。</p>`;
}
function artifactGraph(item){
  return `<div class="artifact-heading"><div><span class="number-label">${esc(diagramTypeLabels[item.type])}</span><h1>${esc(item.title)}</h1></div><button class="button" type="button" id="download-native-artifact">下载此图 HTML</button></div><p class="artifact-notice${item.example?' example':''}">${item.example?'<strong>官方能力示例，非 '+esc(D.name)+' 的项目事实。</strong> ':''}${esc(item.description||'图形内容以本次保存的来源规格和核验回执为准。')}${item.kind==='architecture-delta'?' 使用图内 Before / Delta / After、Review 与前后箭头查看新增、移除、修改、移动和改线。架构比较沿用原生三种预设，Editorial 在这里显示为 Classic。':''}</p><iframe id="native-map" title="${esc(item.title)} · Archify 原生界面" allow="clipboard-write; fullscreen"></iframe><details class="artifact-evidence"><summary>核对这张图的材料与原生校验回执</summary><p>下面保留生成时的输入原文及内容指纹。是否通过 Git 版本核验，以原生回执中的 evidence / proofLevel 为准；材料指纹不证明判断正确。</p>${item.sourceSpecs.map((source,index)=>`<details><summary>${esc(source.label)} · ${esc(source.path.split(/[\\/]/).at(-1))}</summary><p class="small muted">SHA-256：${esc(source.hash)}</p><button class="button" type="button" data-download-spec="${index}">下载这份输入</button><pre>${esc(source.body)}</pre></details>`).join('')}<details><summary>查看完整校验回执</summary><pre>${esc(JSON.stringify(item.receipt,null,2))}</pre></details></details>`;
}
function changeList(delta){
  if(!delta)return '';
  return `<section class="delta-list"><h2>这两个版本之间发生了什么</h2>${delta.hasChanges?`<div class="change-rows">${decisionChanges().map((item,index)=>`<article><button type="button" class="change-target" data-change-index="${index}"><span>${String(index+1).padStart(2,'0')}</span><strong>${esc(item.label)}</strong>${item.detail?`<small>${esc(item.detail)}</small>`:''}</button>${item.sourceId?link('source','查看依据',{doc:item.sourceId,revision:item.revision}):''}</article>`).join('')}</div>`:'<p>资料事实一致，没有决策变化。</p>'}</section>`;
}
function mountNativeMap(){
  const frame=document.getElementById('native-map');if(!frame)return;
  const artifact=activeArtifact();let source,fragment=mapFragment();
  if(artifact)source=artifact.embeddedHtml;
  else{
    const content=state.comparison==='delta'&&comparisonFrame()?comparisonFrame():B.frames[effectiveRevision()];
    source=B.viewerTemplate.replace('<!--DECISION:SVG-->',()=>content.svg).replace('"DECISION:VIEWS"',()=>JSON.stringify(content.views).replaceAll('<','\\u003c'));
    if(!fragment&&state.comparison!=='delta')fragment='view='+(content.views[0]?.id||'');
  }
  activeMapUrl=URL.createObjectURL(new Blob([source],{type:'text/html;charset=utf-8'}));frame.src=activeMapUrl+'#'+fragment;
}
function disposeNativeMap(){stopDecisionReview();if(activeMapUrl){URL.revokeObjectURL(activeMapUrl);activeMapUrl='';}}
function switchDiagram(id){
  if(id!=='decision'&&!(B.artifacts||[]).some(a=>a.id===id))return;
  const current=state.diagram||'decision';diagramLocations[current]={map:mapFragment(),comparison:state.comparison,before:state.before,revision:state.revision,tour:state.tour};
  const next=diagramLocations[id]||{};go({page:'graph',diagram:id,...next});
}
function downloadReadingBlob(body,name,type){const objectUrl=URL.createObjectURL(new Blob([body],{type})),a=document.createElement('a');a.href=objectUrl;a.download=name.replace(/[<>:"/\\|?*]/g,'-');a.click();setTimeout(()=>URL.revokeObjectURL(objectUrl),1000);}
function downloadNativeArtifact(){const item=activeArtifact();if(item)downloadReadingBlob(item.html,item.title+'.html','text/html;charset=utf-8');}
function downloadArtifactSpec(index){const source=activeArtifact()?.sourceSpecs[index];if(source)downloadReadingBlob(source.body,source.path.split(/[\\/]/).at(-1),'application/json;charset=utf-8');}
window.addEventListener('message',event=>{
  const frame=document.getElementById('native-map');if(!frame||event.source!==frame.contentWindow||event.data?.namespace!==viewerNamespace)return;
  const message=event.data,artifact=activeArtifact();if(artifact&&message.diagram!==artifact.id)return;
  if(message.type==='ready')configureViewer();
  if(message.type==='state'){
    setAppearance(message.theme,message.preset);state.map=String(message.fragment||'').slice(0,6000);state.id='';state.mode='near';history.replaceState(capture(),'',hash(state));renderedHash=location.hash;persist();
  }
  if(message.type==='open-record'&&!artifact){
    const revision=effectiveRevision(),dataset=B.versions[revision],card=dataset?.cards.find(c=>c.id===message.id)||B.versions[beforeRevision()]?.cards.find(c=>c.id===message.id);
    if(!card)return;const actualRevision=dataset.cards.some(c=>c.id===card.id)?revision:beforeRevision();
    go(message.page==='source'?{page:'source',doc:card.sourceId,revision:actualRevision}:{page:'decision',id:card.id,revision:actualRevision});
  }
});
