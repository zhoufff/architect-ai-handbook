(() => {
  'use strict';
  if(parent===window)return;
  const namespace='decision-map-viewer-v1';
  let parentUrl='',revision='',last='';
  const post=message=>parent.postMessage({namespace,...message},'*');
  const fragment=()=>location.hash.replace(/^#/,'');
  window.decisionMapLink=value=>{
    if(!parentUrl)return value;
    const original=new URLSearchParams(parentUrl.split('#').slice(1).join('#'));
    const parts=new URLSearchParams({page:'graph',revision,map:String(value).split('#').slice(1).join('#')});
    if(original.get('comparison')==='delta'){parts.set('comparison','delta');if(original.get('before'))parts.set('before',original.get('before'));}
    return parentUrl.split('#')[0]+'#'+parts.toString();
  };
  const publish=()=>{
    const value={type:'state',fragment:fragment(),theme:document.documentElement.dataset.theme,preset:document.documentElement.dataset.preset};
    const encoded=JSON.stringify(value);if(encoded!==last){last=encoded;post(value);}
  };
  const replace=history.replaceState.bind(history);
  history.replaceState=(...args)=>{const result=replace(...args);queueMicrotask(publish);return result;};
  const selected=()=>{const edge=Archify.focus.relationship();if(edge)return edge.to?.slice(1);const id=Archify.focus.active();return typeof id==='string'?id.slice(1):null;};
  const chip=document.getElementById('focus-chip');
  const links=document.createElement('div');links.className='decision-record-actions';links.innerHTML='<button type="button" data-decision-record="decision">阅读决定全文</button><button type="button" data-decision-record="source">核对记录依据</button>';
  chip.append(links);
  const note=document.createElement('div');note.className='decision-record-note';note.textContent='依据为保存的文件快照；未标为 Git 验证。';chip.append(note);
  links.addEventListener('click',e=>{const target=e.target.closest('[data-decision-record]'),id=selected();if(target&&id)post({type:'open-record',page:target.dataset.decisionRecord,id});});
  window.addEventListener('message',event=>{
    if(event.source!==parent||event.data?.namespace!==namespace)return;
    const message=event.data;
    if(message.type==='focus'&&typeof message.fragment==='string')location.hash=message.fragment;
    if(message.type==='configure'){
      parentUrl=String(message.parentUrl||'');revision=String(message.revision||'');
      if(['dark','light'].includes(message.theme)&&document.documentElement.dataset.theme!==message.theme)document.getElementById('btn-theme').click();
      if(['classic','signal-flow','blueprint','editorial'].includes(message.preset))document.querySelector('[data-preset-value="'+message.preset+'"]').click();
      if(message.fragment&&message.fragment!==fragment())location.hash=message.fragment;
      publish();
    }
  });
  new MutationObserver(publish).observe(document.documentElement,{attributes:true,attributeFilter:['data-theme','data-preset']});
  window.addEventListener('hashchange',publish);
  post({type:'ready'});
})();
