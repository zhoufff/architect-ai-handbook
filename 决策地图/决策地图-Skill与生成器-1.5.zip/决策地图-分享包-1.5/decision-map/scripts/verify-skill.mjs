// Dependency-free validation of this package's simple scalar frontmatter and links.
// This does not replace the official YAML validator for arbitrary Skill syntax.
import fs from 'node:fs';
import assert from 'node:assert/strict';
const root=new URL('../',import.meta.url),body=fs.readFileSync(new URL('SKILL.md',root),'utf8'),match=body.match(/^---\r?\n([\s\S]*?)\r?\n---/);
assert.ok(match,'Missing frontmatter');const rows=match[1].split(/\r?\n/).filter(Boolean),fields={};
for(const row of rows){const entry=row.match(/^(name|description): (.+)$/);assert.ok(entry,'Only simple scalar name and description are used by this package');assert.ok(!fields[entry[1]],'Duplicate frontmatter');fields[entry[1]]=entry[2];}
assert.match(fields.name,/^[a-z0-9-]{1,64}$/);assert.ok(fields.description&&fields.description.length<=1024);
const links=[...body.matchAll(/\]\(([^)]+)\)/g)].map(m=>m[1]);for(const link of links){assert.ok(!link.includes('..'),'Skill entry links must stay in package');assert.ok(fs.existsSync(new URL(link,root)),link);}
for(const entry of ['scripts/generate.mjs','scripts/verify.mjs','lib/history.mjs','vendor/archify/LICENSE','upstream-lock.json'])assert.ok(fs.existsSync(new URL(entry,root)),entry);
const result={name:fields.name,frontmatter:'simple-scalars-checked',localLinks:links.length,packageEntrypoints:'present',officialValidator:'not-run: dependency-free structural validation only'};
fs.mkdirSync(new URL('test-results/integration/',root),{recursive:true});
fs.writeFileSync(new URL('test-results/integration/skill-check.json',root),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
