import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { loadArchifyArtifacts } from '../lib/archify-artifacts.mjs';

const gallery = fileURLToPath(new URL('../examples/archify-gallery.json', import.meta.url));
const source = fileURLToPath(new URL('../vendor/archify/examples/brand-aware-delivery.architecture.json', import.meta.url));
const digest = body => createHash('sha256').update(body).digest('hex');
function fixture(run) {
  const parent = fs.realpathSync(fileURLToPath(new URL('../examples/', import.meta.url)));
  const root = fs.mkdtempSync(path.join(parent, 'decision-map-artifact-test-'));
  try {
    fs.copyFileSync(source, path.join(root, 'input.json'));
    const manifest = path.join(root, 'manifest.json');
    const write = items => { fs.writeFileSync(manifest, JSON.stringify({ version: 1, items })); return manifest; };
    run({ root, write, item: { id: 'test', title: 'Test', type: 'architecture', input: 'input.json', example: true } });
  } finally {
    assert.equal(path.dirname(fs.realpathSync(root)), parent);
    fs.rmSync(root, { recursive: true, force: true });
  }
}

test('five native diagrams and architecture compare preserve genuine receipts and hashes', () => {
  const loaded = loadArchifyArtifacts(gallery);
  assert.equal(loaded.items.length, 6);
  assert.equal(loaded.inputFiles.length, 8);
  for (const item of loaded.items) {
    assert.equal(item.example, true);
    assert.match(item.title, /官方示例/);
    assert.equal(item.receipt.ok, true);
    assert.equal(item.receipt.artifact.sha256, digest(item.html));
    assert.match(item.html, /<svg\b/);
    assert.equal(item.receipt.validation.checksPassed, item.type === 'architecture-delta' ? 28 : 9);
    for (const spec of item.sourceSpecs) assert.equal(spec.hash, digest(fs.readFileSync(spec.path)));
  }
  assert.equal(loaded.items.at(-1).receipt.proofLevel, 'authored');
  for (const input of loaded.inputFiles) assert.equal(input.hash, digest(fs.readFileSync(input.path)));
});

test('duplicate and unsafe ids are rejected before native execution', () => fixture(({ write, item }) => {
  assert.throws(() => loadArchifyArtifacts(write([item, { ...item }])), /duplicate/);
  assert.throws(() => loadArchifyArtifacts(write([item, { ...item, id: 'TEST' }])), /duplicate/);
  assert.throws(() => loadArchifyArtifacts(write([{ ...item, id: '../escape' }])), /invalid/);
  assert.throws(() => loadArchifyArtifacts(write([{ ...item, id: 'decision' }])), /invalid/);
  assert.throws(() => loadArchifyArtifacts(write([{ ...item, id: 'DECISION' }])), /invalid/);
}));

test('invalid JSON, invalid diagram, HTML and missing input cannot return an artifact', () => fixture(({ root, write, item }) => {
  for (const body of ['{broken', '<html>untrusted</html>', '{}']) {
    fs.writeFileSync(path.join(root, 'input.json'), body);
    assert.throws(() => loadArchifyArtifacts(write([item])));
  }
  assert.throws(() => loadArchifyArtifacts(write([{ ...item, input: 'missing.json' }])));
  assert.throws(() => loadArchifyArtifacts(write([{ ...item, input: source }])), /relative/);
}));

test('explicit non-Git repository root never becomes verified', () => fixture(({ write, item }) => {
  assert.throws(() => loadArchifyArtifacts(write([{ ...item, repoRoot: '.' }])), /failed|not verified/);
}));
