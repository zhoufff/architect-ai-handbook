// Adapter for projects laid out per the 03 project-rule template:
//   项目总览/md/决策地图.md            map (same fields as the Nexus map.md)
//   专题工作/<专题>/决策卡/NN-*.md      one card per question (same fields as Nexus cards)
//   专题工作/<专题>/专题索引.md          optional; its first heading names the group
// Field and section parsing follows adapters/nexus.mjs so both layouts render the same way.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {sections,plain,slug} from '../lib/markdown.mjs';
export const MAP_FILE='项目总览/md/决策地图.md',MAP_DIR='项目总览/md',TOPICS_DIR='专题工作',CARDS_DIR='决策卡',INDEX_FILES=['专题索引.md','README.md','index.md'],SOURCE_LIMIT=200;
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex'),posix=p=>p.replaceAll('\\','/'),field=(body,key)=>body.match(new RegExp('^'+key+': (.+)$','m'))?.[1].trim()||'';
// Ids must satisfy lib/project.mjs; Chinese names get a stable hashed id, the display title keeps the original text.
export const safeId=(prefix,text)=>{const s=slug(text);return /^[a-z0-9][a-z0-9_-]*$/i.test(s)?s:prefix+'-'+sha(text).slice(0,8);};
export function loadStandard(root){
 root=path.resolve(root);const absolute=rel=>path.join(root,rel),read=rel=>fs.readFileSync(absolute(rel),'utf8').replaceAll('\r\n','\n');
 if(!fs.existsSync(absolute(MAP_FILE)))throw new Error('标准布局缺少地图文件：'+MAP_FILE);
 const sourceRows=new Map(),addSource=(relative,id)=>{if(sourceRows.has(relative))return sourceRows.get(relative);const body=read(relative),file=absolute(relative),s={id:id||'doc-'+sourceRows.size,relative,path:posix(file),title:body.match(/^# (.+)$/m)?.[1].trim()||path.basename(relative),body,hash:sha(fs.readFileSync(file))};sourceRows.set(relative,s);return s;};
 const map=addSource(MAP_FILE,'map'),mapBody=map.body,mapParts=sections(mapBody);
 const agents=fs.existsSync(absolute('AGENTS.md'))?read('AGENTS.md'):'',declared=agents.match(/^\s*-?\s*项目名称[：:]\s*(.+?)\s*$/m)?.[1];
 const name=declared&&!/^\[.*\]$/.test(declared)?declared:path.basename(root),id=safeId('project',name);
 const topicsRoot=absolute(TOPICS_DIR),topics=fs.existsSync(topicsRoot)?fs.readdirSync(topicsRoot,{withFileTypes:true}).filter(e=>e.isDirectory()).map(e=>e.name).sort():[];
 const groups=[],cards=[],cardFiles=new Map(),protectedDirs=new Set([absolute(MAP_DIR)]);
 for(const topic of topics){
  const cardsDir=path.join(topicsRoot,topic,CARDS_DIR);if(!fs.existsSync(cardsDir))continue;protectedDirs.add(cardsDir);
  const names=fs.readdirSync(cardsDir).filter(n=>/^\d+-.*\.md$/.test(n)).sort();if(!names.length)continue;
  const indexName=INDEX_FILES.find(n=>fs.existsSync(path.join(topicsRoot,topic,n))),title=(indexName&&read(posix(path.join(TOPICS_DIR,topic,indexName))).match(/^# (.+)$/m)?.[1].trim())||topic;
  const group={id:safeId('topic',topic),title,ids:[]};if(groups.some(g=>g.id===group.id))throw new Error('专题目录名转成的分组标识重复：'+topic);groups.push(group);
  for(const nameOfCard of names){
   const relative=posix(path.join(TOPICS_DIR,topic,CARDS_DIR,nameOfCard)),cardId=nameOfCard.match(/^(\d+)-/)[1];
   if(cardFiles.has(cardId))throw new Error(`卡 ID 重复：${cardId}（${cardFiles.get(cardId)} 与 ${relative}）`);cardFiles.set(cardId,relative);
   const source=addSource(relative,'card-'+cardId),body=source.body,parts=sections(body),blocked=field(body,'Blocked by');
   const c={id:cardId,title:source.title,status:field(body,'Status'),owner:field(body,'Owner'),assignee:field(body,'Assignee'),type:field(body,'Type'),stage:field(body,'Stage'),date:body.match(/^更新：([^\n]+)/m)?.[1]||'',sourceId:source.id,parts,deps:blocked&&blocked!=='none'?blocked.split(',').map(s=>s.trim()):[],question:parts.find(p=>p.title==='Question')?.body||'',confirmed:parts.filter(p=>p.title==='Answer'||p.title.startsWith('已确认')).map(p=>p.id),remaining:parts.filter(p=>/还需补充|要展开|后续节点|后续处理|尚待后续/.test(p.title)).map(p=>p.id),known:parts.filter(p=>p.title==='已知输入'||p.title.includes('已有证据')||p.title.includes('有限核对')).map(p=>p.id),batchSectionName:field(body,'Batch section')};
   for(const [key,label] of Object.entries({knowledgeStatus:'Knowledge',decisionStatus:'Decision',implementationStatus:'Implementation'})){const value=field(body,label);if(value)c[key]=value;}
   cards.push(c);group.ids.push(cardId);
  }
 }
 if(!cards.length)throw new Error('标准布局没有找到任何决策卡：'+TOPICS_DIR+'/*/'+CARDS_DIR+'/NN-*.md');
 // Embed linked project Markdown for offline reading, following links transitively like nexus.mjs (the Map is iterated live, so files added during the walk are visited too); the linked files stay the only maintained source.
 const isRelative=url=>!/^(https?:|mailto:|#|[a-zA-Z]:|[a-zA-Z][a-zA-Z0-9+.-]*:)/.test(url),linkTarget=(s,url)=>posix(path.relative(root,path.resolve(root,path.dirname(s.relative),url.split('#')[0]||path.basename(s.relative))));
 for(const s of sourceRows.values()){for(const [,url] of s.body.matchAll(/\[[^\]]+\]\(([^)]+)\)/g)){if(!isRelative(url))continue;const rel=linkTarget(s,url);if(rel.startsWith('..')||path.isAbsolute(rel)||!rel.endsWith('.md')||!fs.existsSync(absolute(rel))||fs.statSync(absolute(rel)).isDirectory())continue;addSource(rel);}if(sourceRows.size>SOURCE_LIMIT)throw new Error('来源链接超出范围：超过 '+SOURCE_LIMIT+' 份文件');}
 const unresolvedLinks=[];for(const s of sourceRows.values())for(const [,url] of s.body.matchAll(/\[[^\]]+\]\(([^)]+)\)/g))if(isRelative(url)&&!sourceRows.has(linkTarget(s,url)))unresolvedLinks.push({source:s.relative,url});
 for(const s of sourceRows.values())protectedDirs.add(path.dirname(absolute(s.relative)));
 const batchIds=field(mapBody,'Batch decisions').split(',').map(s=>s.trim()).filter(Boolean),batchStatus=field(mapBody,'Batch status'),batchClosed=/已收敛|已整理完成/.test(batchStatus),summaries=new Map();
 for(const line of(mapParts.find(p=>p.title==='Decisions so far')?.body||'').split('\n')){const m=line.match(/^- \[[^\]]+\]\(([^)]+)\)：(.+)$/),cardId=m&&path.posix.basename(m[1].split('#')[0]).match(/^(\d+)-.*\.md$/)?.[1];if(cardId)summaries.set(cardId,plain(m[2]));}
 const byId=new Map(cards.map(c=>[c.id,c]));
 for(const c of cards){
  // Approval text is not tied to a fixed heading: a `Batch section:` field names it, otherwise the first section titled 已确认… is used.
  const named=c.batchSectionName;delete c.batchSectionName;
  if(named&&!c.parts.some(p=>p.title===named))throw new Error(`卡 ${c.id} 的 Batch section 指向的段落不存在：${named}`);
  const approval=batchIds.includes(c.id)?(named?c.parts.find(p=>p.title===named):c.parts.find(p=>p.title.startsWith('已确认'))):undefined;
  c.batchSection=approval?.id;c.batchChoice=approval?(approval.body.match(/明确选择：\*\*“([^”]+)”\*\*/)?.[1]||plain(approval.body.split('\n\n')[0])):'';c.batchChoiceShort=c.batchChoice.replace(/（推荐[^）]*）/g,'');c.batchTopic=approval?approval.title.replace(/^已确认[的：:\s]*/,''):'';
  c.summary=summaries.get(c.id)||c.batchChoiceShort||plain(c.question.split('\n\n')[0]);
 }
 for(const batchId of batchIds)if(!byId.has(batchId)||(batchClosed&&!byId.get(batchId).batchChoice))throw new Error(`本批结论无法从原卡定位: ${batchId}`);
 const next=mapParts.find(p=>p.title==='当前下一步');
 return{version:'0.1.0',id,name,phase:field(mapBody,'Phase'),date:mapBody.match(/更新：([\d-]+)/)?.[1]||'',mapVersion:mapBody.match(/更新：[^\n]+ · (v[\d.]+)/)?.[1]||'',batch:{ids:batchIds,status:batchStatus,closed:batchClosed,nextBody:next?.body||'',summary:plain(next?.body.split('\n\n')[0]||'')},groups,cards,sources:[...sourceRows.values()],unresolvedLinks,inputFiles:[...sourceRows.values()].map(s=>({path:s.path,hash:s.hash})),protectedDirs:[...protectedDirs].map(posix).sort(),generated:new Date().toISOString()};
}
