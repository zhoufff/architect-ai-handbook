// Transparent access to every command of the pinned native tool, with original
// arguments, standard streams, working directory and exit status preserved.
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const cli=fileURLToPath(new URL('../vendor/archify/bin/archify.mjs',import.meta.url));
const run=spawnSync(process.execPath,[cli,...process.argv.slice(2)],{stdio:'inherit',shell:false});
if(run.error){console.error(run.error.message);process.exitCode=1;}else process.exitCode=run.status??1;
