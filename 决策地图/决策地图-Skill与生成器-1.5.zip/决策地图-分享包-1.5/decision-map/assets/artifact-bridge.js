(function () {
  'use strict';
  const namespace = 'decision-map-viewer-v1';
  const meta = window.__decisionMapArtifact;
  const delta = meta.kind === 'architecture-delta';
  let config = null;
  let restoring = false;
  let lastState = '';
  const nestedFragments = { base: '', head: '' };
  const root = document.documentElement;
  const clean = (value) => String(value || '').replace(/^#/, '');
  const tabs = () => [...document.querySelectorAll('[data-target]')];
  const rows = () => [...document.querySelectorAll('[data-change-key]')];
  function fragment() {
    if (!delta) return clean(location.hash);
    const tab = tabs().find((node) => node.getAttribute('aria-selected') === 'true')?.dataset.target || 'delta';
    const row = rows().find((node) => node.getAttribute('aria-current') === 'step');
    const params = new URLSearchParams({ tab });
    if (row) params.set('change', row.dataset.changeKey);
    if (nestedFragments[tab]) params.set('native', nestedFragments[tab]);
    return params.toString();
  }
  function send(type, extra) {
    window.parent.postMessage({ namespace, type, diagram: meta.id, ...extra }, '*');
  }
  function state() {
    if (!config || restoring) return;
    const value = { fragment: fragment(), theme: root.dataset.theme, preset: root.dataset.preset };
    const serialized = JSON.stringify(value);
    if (serialized === lastState) return;
    lastState = serialized;
    send('state', value);
    if (delta) configureFrames();
  }
  function share(value) {
    if (!config?.parentUrl) return value;
    let native;
    try { native = clean(new URL(value, location.href).hash); } catch (_) { return value; }
    if (meta.snapshotTab) {
      const params = new URLSearchParams({ tab: meta.snapshotTab });
      if (config.change) params.set('change', config.change);
      if (native) params.set('native', native);
      native = params.toString();
    }
    const url = new URL(config.parentUrl);
    ['decision', 'comparison', 'before'].forEach((key) => url.searchParams.delete(key));
    url.hash = new URLSearchParams({ page: 'graph', diagram: config.diagram || meta.id, map: native }).toString();
    return url.href;
  }
  window.DecisionMapArtifact = { share };
  // Native viewers use replaceState, which neither fires hashchange nor accepts
  // pathname-only blob URLs. Keep their updates within this document.
  for (const method of ['replaceState', 'pushState']) {
    const original = history[method].bind(history);
    history[method] = function (data, title, url) {
      if (url == null) return original(data, title);
      const text = String(url);
      const hash = text.includes('#') ? text.slice(text.indexOf('#')) : '';
      const target = location.href.replace(/#.*$/, '') + hash;
      try { original(data, title, target); }
      catch (_) { if (location.hash !== hash) location.hash = hash; }
      queueMicrotask(state);
    };
  }
  function restore(value) {
    restoring = true;
    try {
      if (delta) {
        const params = new URLSearchParams(clean(value));
        const tab = ['base', 'head', 'delta'].includes(params.get('tab')) ? params.get('tab') : 'delta';
        const row = rows().find((node) => node.dataset.changeKey === params.get('change'));
        if (row) row.click();
        else document.querySelector('#review-overview')?.click();
        tabs().find((node) => node.dataset.target === tab)?.click();
        if (tab !== 'delta') nestedFragments[tab] = params.get('native') || '';
      } else {
        history.replaceState(null, '', location.href.replace(/#.*$/, '') + (clean(value) ? '#' + clean(value) : ''));
        window.dispatchEvent(new Event('hashchange'));
      }
    } finally { restoring = false; }
  }
  function appearance(theme, preset) {
    if (['light', 'dark'].includes(theme) && root.dataset.theme !== theme) {
      if (window.Archify?.theme?.toggle) window.Archify.theme.toggle();
      else root.dataset.theme = theme;
    }
    if (delta) {
      if (preset === 'editorial') preset = 'classic';
      if (['classic', 'signal-flow', 'blueprint'].includes(preset)) root.dataset.preset = preset;
    } else if (['classic', 'signal-flow', 'blueprint', 'editorial'].includes(preset)) window.Archify?.preset?.apply(preset);
  }
  function frames() { return [...document.querySelectorAll('iframe.snapshot-frame')]; }
  function configureFrame(frame, index) {
    if (!config) return;
    const tab = index === 0 ? 'base' : 'head';
    const change = rows().find((node) => node.getAttribute('aria-current') === 'step')?.dataset.changeKey;
    frame.contentWindow?.postMessage({ namespace, type: 'configure', ...config, fragment: nestedFragments[tab], change, theme: root.dataset.theme, preset: root.dataset.preset }, '*');
  }
  function configureFrames() { frames().forEach(configureFrame); }
  window.addEventListener('message', function (event) {
    const data = event.data;
    if (!data || data.namespace !== namespace) return;
    if (delta && event.source !== window.parent) {
      const index = frames().findIndex((frame) => frame.contentWindow === event.source);
      if (index < 0) return;
      if (data.type === 'ready') configureFrame(frames()[index], index);
      if (data.type === 'state') {
        nestedFragments[index === 0 ? 'base' : 'head'] = clean(data.fragment);
        appearance(data.theme, data.preset);
        state();
      }
      return;
    }
    if (event.source !== window.parent || data.diagram && data.diagram !== meta.id) return;
    if (data.type === 'configure') {
      config = data;
      appearance(data.theme, data.preset);
      restore(data.fragment);
      if (delta) configureFrames();
      state();
    } else if (data.type === 'focus' && config) {
      restore(data.fragment);
      if (delta) configureFrames();
      state();
    }
  });
  window.addEventListener('hashchange', state);
  window.addEventListener('DOMContentLoaded', function () {
    new MutationObserver(state).observe(root, { attributes: true, subtree: delta, attributeFilter: ['data-theme', 'data-preset', 'aria-current', 'aria-selected'] });
    send('ready');
  });
})();
