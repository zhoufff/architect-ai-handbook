let decisionReviewTimer=0,decisionReviewPlaying=false;
const changeFieldLabels={title:'问题名称',question:'问题原文',summary:'导读结论',status:'整卡状态',owner:'决定责任',assignee:'实际承接',stage:'阶段',deps:'前置依赖',parts:'记录正文',confirmed:'已确认内容',remaining:'后续工作',known:'已知依据',batchChoice:'本批选择',batchChoiceShort:'本批结论',batchTopic:'本批对象',batchSection:'批准段落',knowledgeStatus:'认知与依据',decisionStatus:'决定与批准',implementationStatus:'实现与验证'};
function decisionChanges(){
  const delta=comparisonData();if(!delta)return [];
  const before=B.versions[beforeRevision()],after=B.versions[activeRevision()];
  const card=id=>after.cards.find(c=>c.id===id)||before.cards.find(c=>c.id===id);
  const items=[];
  for(const [ids,label]of [[delta.added,'新增问题'],[delta.removed,'移除问题']])for(const id of ids)items.push({key:'node:'+id,id,label:label+' · '+card(id)?.title,fragment:'focus='+encodeURIComponent('d'+id),sourceId:card(id)?.sourceId,revision:after.cards.some(c=>c.id===id)?activeRevision():beforeRevision()});
  for(const entry of delta.changed)items.push({key:'node:'+entry.id,id:entry.id,label:'内容变化 · '+card(entry.id)?.title,detail:entry.fields.map(f=>changeFieldLabels[f]||f).join('、'),fragment:'focus='+encodeURIComponent('d'+entry.id),sourceId:card(entry.id)?.sourceId,revision:activeRevision()});
  for(const [edges,label]of [[delta.relationsAdded,'新增依赖'],[delta.relationsRemoved,'移除依赖']])for(const edge of edges){const removed=label==='移除依赖',sourceCard=(removed?before:after).cards.find(c=>c.id===edge.to);items.push({key:'edge:'+edge.id,label:label+' · '+edge.from+' → '+edge.to,fragment:'relation='+encodeURIComponent('dep-'+edge.from+'-'+edge.to),sourceId:sourceCard?.sourceId,revision:removed?beforeRevision():activeRevision()});}
  for(const entry of delta.evidenceChanged)items.push({key:'evidence:'+entry.id,label:'依据变化 · '+(card(entry.id)?.title||entry.id),detail:entry.sourceIds.join('、'),fragment:card(entry.id)?'focus='+encodeURIComponent('d'+entry.id):'',sourceId:entry.sourceIds[0],revision:after.sources.some(s=>s.id===entry.sourceIds[0])?activeRevision():beforeRevision()});
  if(delta.batchChanged)items.push({key:'batch',label:'本批安排变化',fragment:'',sourceId:after.sources.some(s=>s.id==='map')?'map':undefined,revision:activeRevision()});
  return items;
}
function currentDecisionChange(){return decisionChanges().find(item=>item.key===state.tour);}
function decisionReviewBar(){
  const items=decisionChanges();if(!items.length)return '';
  const current=currentDecisionChange(),index=current?items.findIndex(i=>i.key===current.key):-1;
  return `<section class="decision-review" aria-label="逐项巡览决策变化"><div class="review-buttons"><button type="button" data-review="overview">全图</button><button type="button" data-review="previous" aria-label="上一项变化"${index<=0?' disabled':''}>←</button><button type="button" data-review="play" aria-pressed="${decisionReviewPlaying}">${decisionReviewPlaying?'暂停':'巡览变化'}</button><button type="button" data-review="next" aria-label="下一项变化"${index===items.length-1?' disabled':''}>→</button></div><div class="review-caption" role="status"><strong>${current?`${index+1} / ${items.length} · ${esc(current.label)}`:`${items.length} 项变化 · 逐项查看对象与依据`}</strong>${current?.detail?`<small>${esc(current.detail)}</small>`:''}</div>${current?.sourceId?link('source','核对本次依据',{doc:current.sourceId,revision:current.revision},'button'):''}</section>`;
}
function refreshDecisionReview(){const target=document.getElementById('decision-review-slot');if(target)target.innerHTML=decisionReviewBar();}
function setMapFragment(fragment){state.map=fragment;state.id='';state.mode='near';history.replaceState(capture(),'',hash(state));renderedHash=location.hash;persist();const frame=document.getElementById('native-map');frame?.contentWindow.postMessage({namespace:viewerNamespace,type:'focus',fragment},'*');}
function stopDecisionReview(){clearTimeout(decisionReviewTimer);decisionReviewTimer=0;decisionReviewPlaying=false;}
function selectDecisionChange(index){const item=decisionChanges()[index];if(!item)return false;state.tour=item.key;setMapFragment(item.fragment);refreshDecisionReview();return true;}
function scheduleDecisionReview(){
  clearTimeout(decisionReviewTimer);if(!decisionReviewPlaying)return;
  decisionReviewTimer=setTimeout(()=>{if(document.hidden){stopDecisionReview();refreshDecisionReview();return;}const items=decisionChanges(),index=items.findIndex(i=>i.key===state.tour);if(index>=items.length-1){stopDecisionReview();refreshDecisionReview();return;}selectDecisionChange(index+1);scheduleDecisionReview();},3500);
}
function handleDecisionReview(action){
  const items=decisionChanges(),index=items.findIndex(i=>i.key===state.tour);
  if(action!=='play')stopDecisionReview();
  if(action==='overview'){state.tour='';setMapFragment('');refreshDecisionReview();return;}
  if(action==='previous'||action==='next'){selectDecisionChange(Math.max(0,Math.min(items.length-1,index+(action==='next'?1:-1))));return;}
  if(action==='play'){
    if(decisionReviewPlaying){stopDecisionReview();refreshDecisionReview();return;}
    if(!items.length)return;
    if(window.matchMedia?.('(prefers-reduced-motion: reduce)').matches){selectDecisionChange(index<items.length-1?index+1:0);return;}
    decisionReviewPlaying=true;selectDecisionChange(index<0||index===items.length-1?0:index);scheduleDecisionReview();
  }
}
document.addEventListener('visibilitychange',()=>{if(document.hidden){stopDecisionReview();refreshDecisionReview();}});
