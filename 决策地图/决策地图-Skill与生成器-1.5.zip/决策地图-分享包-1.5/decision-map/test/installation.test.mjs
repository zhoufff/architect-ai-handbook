import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';

test('generator runs through a linked skill directory and resolves all package resources',t=>{
  const source=fs.realpathSync(fileURLToPath(new URL('../',import.meta.url)));
  const parent=path.join(source,'test-results');
  fs.mkdirSync(parent,{recursive:true});
  const directory=fs.mkdtempSync(path.join(parent,'install-link-test-'));
  const link=path.join(directory,'linked-skill');
  t.after(()=>{assert.equal(path.dirname(directory),parent);assert.ok(path.basename(directory).startsWith('install-link-test-'));assert.equal(fs.realpathSync(directory),directory);fs.rmSync(directory,{recursive:true,force:true});assert.ok(fs.existsSync(path.join(source,'SKILL.md')));});
  fs.symlinkSync(source,link,process.platform==='win32'?'junction':'dir');
  const output=path.join(directory,'sample.html');
  const result=spawnSync(process.execPath,[path.join(link,'scripts/generate.mjs'),'--data',path.join(source,'examples/community.json'),'--output',output],{encoding:'utf8',shell:false,windowsHide:true});
  assert.equal(result.status,0,result.stderr);
  assert.ok(fs.existsSync(output),'the linked CLI must create the requested file');
  const receipt=JSON.parse(result.stdout);
  assert.equal(receipt.project,'community-example');assert.equal(receipt.historyCount,1);
  const html=fs.readFileSync(output,'utf8');assert.match(html,/id="bundle"/);assert.match(html,/var Archify =/);
});
