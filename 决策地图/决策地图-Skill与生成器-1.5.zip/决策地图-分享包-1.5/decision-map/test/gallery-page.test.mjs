import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {fileURLToPath} from 'node:url';
import {normalizeProject} from '../lib/project.mjs';
import {renderPage} from '../lib/render-page.mjs';
import {loadArchifyArtifacts} from '../lib/archify-artifacts.mjs';
import {compareSnapshots} from '../lib/history.mjs';
const root=new URL('../',import.meta.url);
const native=fs.readFileSync(new URL('assets/native-map.js',root),'utf8'),review=fs.readFileSync(new URL('assets/decision-review.js',root),'utf8');
const fixture=()=>normalizeProject(JSON.parse(fs.readFileSync(new URL('examples/community.json',root),'utf8')));

test('all six native artifacts have selectable page entries, truthful labels, material and receipts',()=>{
  const data=fixture(),before=structuredClone(data);const artifacts=loadArchifyArtifacts(fileURLToPath(new URL('examples/archify-gallery.json',root))).items;
  const html=renderPage(data,[{id:'one',createdAt:'2026-09-14T00:00:00Z',mapVersion:'v1'}],{one:data},'one',artifacts),bundle=JSON.parse(html.match(/id="bundle">([\s\S]*?)<\/script>/)[1]),script=html.match(/<script>([\s\S]*?)<\/script>/)[1];
  assert.equal(bundle.artifacts.length,6);assert.equal(bundle.entries.length,1);assert.deepEqual(data,before,'gallery never mutates decision facts');
  for(const item of bundle.artifacts){
    assert.ok(item.receipt.ok);assert.ok(item.example);assert.match(item.embeddedHtml,/decision-map-viewer-v1/);
    const app={innerHTML:''},location={hash:'#page=graph&diagram='+item.id,href:'https://example.invalid/#page=graph&diagram='+item.id};
    const context={URLSearchParams,location,history:{state:null,replaceState(state){this.state=state;}},document:{getElementById:id=>id==='dataset'?{textContent:JSON.stringify(data)}:id==='bundle'?{textContent:JSON.stringify(bundle)}:id==='app'?app:null,documentElement:{dataset:{theme:'dark',preset:'blueprint'}},body:{classList:{toggle(){}}},querySelectorAll:()=>[],addEventListener(){}},window:{addEventListener(){}},localStorage:{getItem:()=>null},requestAnimationFrame(){},setTimeout(){},clearTimeout(){}};
    vm.runInNewContext(script,context);
    assert.match(app.innerHTML,/官方能力示例，非/);assert.match(app.innerHTML,/材料与原生校验回执/);assert.match(app.innerHTML,/data-download-spec="0"/);assert.match(app.innerHTML,/id="download-native-artifact"/);
    for(const candidate of artifacts)assert.ok(app.innerHTML.includes('value="'+candidate.id+'"'));
    if(item.kind==='architecture-delta')assert.match(app.innerHTML,/Review/);
  }
});

test('switching between decision and native maps restores separate reading state',()=>{
  const context={state:{page:'graph',diagram:'decision',map:'focus=d08',comparison:'delta',before:'old',revision:'new',tour:'node:08'},B:{artifacts:[{id:'architecture'}]},window:{addEventListener(){}},URLSearchParams};
  context.go=next=>context.state={...next};vm.createContext(context);vm.runInContext(native,context);
  vm.runInContext('switchDiagram("architecture")',context);context.state.map='focus=api';
  vm.runInContext('switchDiagram("decision")',context);assert.equal(context.state.map,'focus=d08');assert.equal(context.state.comparison,'delta');assert.equal(context.state.tour,'node:08');
  vm.runInContext('switchDiagram("architecture")',context);assert.equal(context.state.map,'focus=api');assert.equal(context.state.diagram,'architecture');
});

test('technical nodes cannot open decision cards even when ids match; messages from other frames are ignored',()=>{
  const contentWindow={},messages=[];let listener,opened=false;
  const context={state:{diagram:'architecture',revision:'new',comparison:'after',map:''},B:{currentId:'new',artifacts:[{id:'architecture'}],entries:[{id:'new'}]},document:{getElementById:()=>({contentWindow:{...contentWindow,postMessage:m=>messages.push(m)}})},window:{addEventListener:(_,fn)=>listener=fn},go:()=>opened=true};
  // Use one stable WindowProxy identity just as the host's source check requires.
  const frameWindow={postMessage:m=>messages.push(m)};context.document.getElementById=()=>({contentWindow:frameWindow});
  vm.runInNewContext(native,context);
  listener({source:frameWindow,data:{namespace:'decision-map-viewer-v1',diagram:'architecture',type:'open-record',id:'08'}});assert.equal(opened,false);
  listener({source:{},data:{namespace:'decision-map-viewer-v1',diagram:'architecture',type:'ready'}});assert.equal(messages.length,0);
});

test('decision review resolves exact node/edge/evidence and finishes a finite tour',()=>{
  const old=fixture(),current=structuredClone(old);current.cards[1].summary='changed';current.cards[1].deps=[];current.sources[2].body+='\nnew evidence';current.cards[1].sourceId='replacement-02';current.sources[2].id='replacement-02';
  const delta=compareSnapshots(old,current),timers=[];let stopped=0;const sent=[];
  const context={state:{diagram:'decision',comparison:'delta',revision:'new',before:'old',map:'',tour:''},B:{currentId:'new',entries:[{id:'old'},{id:'new'}],versions:{old,new:current},deltas:{'old~new':delta}},URLSearchParams,location:{hash:''},document:{hidden:false,addEventListener(){},getElementById:id=>id==='native-map'?{contentWindow:{postMessage:m=>sent.push(m)}}:null},window:{addEventListener(){},matchMedia:()=>({matches:false})},history:{replaceState(){}},capture:()=>({}),hash:()=>'',persist(){},renderedHash:'',setTimeout:fn=>{timers.push(fn);return timers.length;},clearTimeout(){stopped++;}};
  vm.createContext(context);vm.runInContext(native+'\n'+review,context);
  const items=vm.runInContext('decisionChanges()',context);assert.ok(items.some(i=>i.key==='node:02'));assert.ok(items.some(i=>i.fragment==='relation=dep-01-02'));assert.ok(items.some(i=>i.key==='evidence:02'));assert.equal(items.find(i=>i.key==='edge:01>02').sourceId,'card-02');assert.equal(items.find(i=>i.key==='edge:01>02').revision,'old');
  vm.runInContext('handleDecisionReview("play")',context);let steps=0;while(timers.length){timers.shift()();assert.ok(++steps<=items.length+1,'must terminate without looping');}
  assert.equal(vm.runInContext('decisionReviewPlaying',context),false);assert.equal(context.state.tour,items.at(-1).key);assert.ok(sent.length>=items.length);assert.ok(stopped>0);
});
