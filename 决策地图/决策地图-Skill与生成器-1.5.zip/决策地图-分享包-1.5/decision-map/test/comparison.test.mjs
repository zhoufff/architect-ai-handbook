import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {comparisonLayout} from '../lib/compare-layout.mjs';
import {renderDecisionComparison} from '../lib/render-map.mjs';
import {compareSnapshots} from '../lib/history.mjs';
import {renderPage} from '../lib/render-page.mjs';

const project=rows=>({id:'test',name:'测试项目',groups:[],sources:[],cards:rows.map(([id,deps])=>({id,deps,title:id,status:'open',sourceId:'record-'+id,summary:id}))});
function checkEndpoints(result){
  const {layout}=result;
  for(const edge of layout.paths){
    for(const [id,point] of [[edge.from,edge.points[0]],[edge.to,edge.points.at(-1)]]){
      const p=layout.positions.get(id),[x,y]=point;
      assert.ok(x>=p.x&&x<=p.x+p.w&&y>=p.y&&y<=p.y+p.h,`${edge.id} must connect to ${id}`);
    }
    for(const [x,y] of edge.points)assert.ok(x>=0&&x<=layout.width&&y>=0&&y<=layout.height);
  }
  assert.equal(new Set(layout.paths.map(e=>e.id)).size,layout.paths.length);
}
test('removed dependency is rerouted against the same positions as surviving nodes',()=>{
  const a=project([['a',[]],['b',['a']],['c',['b']]]),b=project([['a',[]],['b',[]],['c',['b']]]);
  const result=comparisonLayout(a,b);
  assert.equal(result.layout.paths.length,2);assert.equal(result.cyclic,false);checkEndpoints(result);
  assert.deepEqual(b.cards[1].deps,[],'source data remains unchanged');
});
test('dependency reversal keeps both directions without assuming a DAG',()=>{
  const a=project([['a',[]],['b',['a']],['c',['b']]]),b=project([['a',['b']],['b',[]],['c',['b']]]);
  const result=comparisonLayout(a,b);assert.equal(result.cyclic,true);assert.equal(result.layout.paths.length,3);checkEndpoints(result);
  for(const edge of result.layout.paths){
    const lane=edge.points[1][0];
    for(const p of result.layout.positions.values())assert.ok(lane>p.x+p.w,'vertical routing stays outside all nodes');
  }
});
test('removed and added nodes and relations retain distinct inspectable semantics',()=>{
  const a=project([['a',[]],['b',['a']]]),b=project([['a',[]],['c',['a']]]);
  const rendered=renderDecisionComparison(a,b,compareSnapshots(a,b));
  assert.deepEqual(rendered.counts,{nodes:3,edges:2});
  assert.match(rendered.svg,/data-node-id="db"/);assert.match(rendered.svg,/已移除 · 旧版本/);
  assert.match(rendered.svg,/decision-removed-edge/);assert.match(rendered.svg,/decision-added-edge/);
  assert.match(rendered.svg,/decision-removed/);assert.match(rendered.svg,/decision-added/);checkEndpoints(rendered);
});
test('detail map links become native focus and reachability fragments',()=>{
  const context={state:{id:'b',mode:'upstream',map:''},B:{artifacts:[]},URLSearchParams,window:{addEventListener(){}}};
  vm.createContext(context);vm.runInContext(fs.readFileSync(new URL('../assets/native-map.js',import.meta.url),'utf8'),context);
  assert.equal(vm.runInContext('mapFragment()',context),'focus=db&reach=upstream');
  context.state.mode='near';assert.equal(vm.runInContext('mapFragment()',context),'focus=db');
  context.state.map='relation=dep-a-b';assert.equal(vm.runInContext('mapFragment()',context),'relation=dep-a-b');
});
test('Delta source-record action uses the removed node original snapshot',()=>{
  let listener,opened;
  const contentWindow={},context={state:{comparison:'delta',revision:'new',before:'old'},B:{currentId:'new',entries:[{id:'old'},{id:'new'}],versions:{old:project([['b',[]]]),new:project([['a',[]]])}},document:{getElementById:()=>({contentWindow})},window:{addEventListener:(_,fn)=>listener=fn},go:v=>opened=v};
  vm.createContext(context);vm.runInContext(fs.readFileSync(new URL('../assets/native-map.js',import.meta.url),'utf8'),context);
  listener({source:contentWindow,data:{namespace:'decision-map-viewer-v1',type:'open-record',id:'b',page:'source'}});
  assert.equal(opened.revision,'old');assert.equal(opened.doc,'record-b');
});
test('page embeds comparison frames while preserving each original version',()=>{
  const old=project([['a',[]],['b',['a']]]),current=project([['a',['b']],['b',[]]]);
  const html=renderPage(current,[{id:'old'},{id:'new'}],{old,new:current},'new');
  const bundle=JSON.parse(html.match(/id="bundle">([\s\S]*?)<\/script>/)[1]);
  assert.equal(bundle.comparisonFrames['old~new'].cyclic,true);
  assert.deepEqual(bundle.comparisonFrames['old~new'].counts,{nodes:2,edges:2});
  assert.deepEqual(bundle.frames.old.counts,{nodes:2,edges:1});
  assert.deepEqual(bundle.frames.new.counts,{nodes:2,edges:1});
  assert.ok(bundle.viewerTemplate.includes('var Archify = {}'));
});
test('copied Delta links preserve the baseline and comparison mode',()=>{
  let listener;
  const element={append(){},addEventListener(){}};
  const parent={postMessage(){}},context={parent,window:{addEventListener:(type,fn)=>{if(type==='message')listener=fn;}},URLSearchParams,location:{hash:''},history:{replaceState(){}},document:{documentElement:{dataset:{theme:'dark',preset:'blueprint'}},getElementById:()=>element,createElement:()=>({...element}),querySelector:()=>({click(){}})},MutationObserver:class{observe(){}},Archify:{focus:{}},queueMicrotask(){}};
  vm.createContext(context);vm.runInContext(fs.readFileSync(new URL('../assets/map-bridge.js',import.meta.url),'utf8'),context);
  listener({source:parent,data:{namespace:'decision-map-viewer-v1',type:'configure',parentUrl:'file:///map.html#page=graph&comparison=delta&before=old',revision:'new'}});
  const copied=context.window.decisionMapLink('blob:any#focus=db');
  const params=new URLSearchParams(copied.split('#')[1]);
  assert.equal(params.get('comparison'),'delta');assert.equal(params.get('before'),'old');assert.equal(params.get('revision'),'new');assert.equal(params.get('map'),'focus=db');
});
