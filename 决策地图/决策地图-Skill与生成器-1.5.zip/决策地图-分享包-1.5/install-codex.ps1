#Requires -Version 7.0
[CmdletBinding(SupportsShouldProcess = $true)]
param([string]$SkillsDirectory = (Join-Path ([Environment]::GetFolderPath('UserProfile')) '.agents/skills'))
$ErrorActionPreference = 'Stop'
$packageRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$sourceRoot = Join-Path $packageRoot 'decision-map'
$manifest = Get-Content -LiteralPath (Join-Path $packageRoot 'package-manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$skillParent = [IO.Path]::GetFullPath($SkillsDirectory)
$destination = Join-Path $skillParent 'decision-map'
if (Test-Path -LiteralPath $destination) { throw "Already exists; nothing was overwritten: $destination" }
if (-not (Test-Path -LiteralPath (Join-Path $sourceRoot 'SKILL.md'))) { throw 'Extract the complete ZIP before installation.' }
$entries = @($manifest.files.PSObject.Properties | Where-Object { $_.Name.StartsWith('decision-map/') })
if ($entries.Count -eq 0) { throw 'No skill files in package manifest.' }
foreach ($entry in $entries) {
    if ($entry.Name -match '(^|/)[.][.]?(/|$)|\\|:') { throw "Unsafe manifest path: $($entry.Name)" }
    $sourceFile = [IO.Path]::GetFullPath((Join-Path $packageRoot $entry.Name))
    if (-not $sourceFile.StartsWith($sourceRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Source escapes skill directory.' }
    $hash = (Get-FileHash -LiteralPath $sourceFile -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($hash -ne $entry.Value) { throw "Package damaged or changed: $($entry.Name)" }
}
if (-not $PSCmdlet.ShouldProcess($destination, "Install $($entries.Count) verified skill files")) { return }
[IO.Directory]::CreateDirectory($skillParent) | Out-Null
$staging = Join-Path $skillParent ('decision-map.install-' + [Guid]::NewGuid().ToString('N'))
if ([IO.Path]::GetDirectoryName($staging) -ne $skillParent -or [IO.Path]::GetDirectoryName($destination) -ne $skillParent) { throw 'Invalid installation destination.' }
[IO.Directory]::CreateDirectory($staging) | Out-Null
foreach ($entry in $entries) {
    $relative = $entry.Name.Substring('decision-map/'.Length)
    $targetFile = Join-Path $staging $relative
    [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($targetFile)) | Out-Null
    Copy-Item -LiteralPath (Join-Path $packageRoot $entry.Name) -Destination $targetFile
    if ((Get-FileHash -LiteralPath $targetFile -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.Value) { throw "Copy verification failed; staging retained: $staging" }
}
if (Test-Path -LiteralPath $destination) { throw "Destination appeared during installation; staging retained: $staging" }
Move-Item -LiteralPath $staging -Destination $destination
[pscustomobject]@{ skill = 'decision-map'; destination = $destination; filesVerified = $entries.Count; mode = 'independent-copy'; previousFilesOverwritten = $false } | ConvertTo-Json
