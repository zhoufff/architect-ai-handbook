import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import vm from 'node:vm';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {generate,detectLayout} from '../scripts/generate.mjs';
import {loadStandard,safeId} from '../adapters/standard.mjs';
import {writeStandardProject,tree} from './helpers/standard-project.mjs';
const datasetFrom=html=>JSON.parse(html.match(/<script type="application\/json" id="dataset">([\s\S]*?)<\/script>/)[1]);
const scripts=fileURLToPath(new URL('../scripts/',import.meta.url));
function directory(t){const d=fs.mkdtempSync(path.join(os.tmpdir(),'decision-standard-'));t.after(()=>fs.rmSync(d,{recursive:true,force:true}));return d;}
const relativeAll=(root,list)=>list.map(p=>path.relative(root,p).replaceAll('\\','/')).sort();

test('a fictional standard-layout project renders into 项目总览/html with topic groups, history and a stable second run',t=>{
  const root=path.join(directory(t),'示例项目');writeStandardProject(root);
  const output=path.join(root,'项目总览/html/决策地图.html'),first=generate({sourceRoot:root,output});
  assert.equal(first.layout,'standard');assert.equal(first.packageVersion,'1.5');assert.equal(first.cards,4);assert.equal(first.confirmed,1);assert.deepEqual(first.batchIds,['01']);
  assert.match(first.project,/^project-[a-f0-9]{8}$/);assert.equal(first.createdSnapshot,true);assert.equal(first.historyCount,1);
  assert.equal(first.historyDirectory,path.join(root,'项目总览/html/.decision-map-history',first.project));assert.ok(fs.existsSync(path.join(first.historyDirectory,'index.json')));
  assert.ok(fs.existsSync(path.join(root,'项目总览/html/决策地图.生成记录.json')));
  assert.deepEqual(relativeAll(root,first.protectedDirs),['专题工作/场地与噪声','专题工作/场地与噪声/决策卡','专题工作/开放安排/决策卡','资料','项目总览/md'],'linked sources protect their directories, transitively');
  const data=datasetFrom(fs.readFileSync(output,'utf8'));
  assert.equal(data.name,'示例河畔书屋');assert.equal(data.phase,'探索期');assert.equal(data.mapVersion,'v1');assert.equal(data.date,'2026-09-16');
  assert.deepEqual(data.groups.map(g=>[g.id,g.title,g.ids]),[[safeId('topic','场地与噪声'),'场地与噪声（示例专题）',['01','02']],[safeId('topic','开放安排'),'开放安排',['03','04']]]);
  const byId=Object.fromEntries(data.cards.map(c=>[c.id,c]));
  assert.deepEqual(byId['02'].deps,['01']);assert.deepEqual(byId['01'].following,['02']);assert.equal(byId['02'].type,'research');assert.equal(byId['02'].knowledgeStatus,'assumed');assert.equal(byId['04'].knowledgeStatus,undefined);
  assert.equal(byId['01'].summary,'示例：主要使用者为周边居民。');assert.equal(byId['01'].batchChoice,'选择周边居民为主要使用者（示例）。');assert.equal(byId['01'].batchTopic,'用户批准');assert.equal(byId['01'].decisionStatus,'confirmed');
  assert.equal(byId['03'].batchChoice,'','cards outside the batch carry no approval');assert.equal(byId['03'].batchSection,undefined);assert.equal(byId['03'].summary,'每天开放多久？');
  assert.deepEqual(byId['02'].remaining.map(id=>byId['02'].parts.find(p=>p.id===id).title),['还需补充']);assert.deepEqual(byId['02'].known.length,1);
  assert.equal(data.batch.closed,true);assert.match(data.batch.nextHtml,/继续核对噪声来源/);
  assert.deepEqual(data.sources.map(s=>s.relative),['项目总览/md/决策地图.md','专题工作/场地与噪声/决策卡/01-谁会使用.md','专题工作/场地与噪声/决策卡/02-噪声来源.md','专题工作/开放安排/决策卡/03-开放时段.md','专题工作/开放安排/决策卡/04-回访安排.md','专题工作/场地与噪声/噪声记录.md','资料/测量报告.md'],'a document linked only from another linked document is embedded too');
  assert.match(byId['02'].questionHtml,/#page=source&amp;doc=doc-5/);assert.match(data.sources[5].html,/#page=source&amp;doc=doc-6/);assert.deepEqual(data.unresolvedLinks,[]);
  const second=generate({sourceRoot:root,output});
  assert.equal(second.createdSnapshot,false);assert.equal(second.historyCount,1);assert.equal(second.snapshot.id,first.snapshot.id);
  const verify=spawnSync(process.execPath,[path.join(scripts,'verify.mjs'),output],{encoding:'utf8',windowsHide:true});assert.equal(verify.status,0,verify.stderr);
  const checks=JSON.parse(verify.stdout);assert.equal(checks.cards,4);assert.equal(checks.relations,1);assert.equal(checks.originalSourcesUnchanged,7);
});

test('ascii project and topic names keep readable ids; missing 项目名称 falls back to the directory name',t=>{
  const dir=directory(t),root=path.join(dir,'riverside');writeStandardProject(root,{name:'Riverside Reading Room',topics:['site-survey','opening-plan']});
  const data=loadStandard(root);assert.equal(data.id,'riverside-reading-room');assert.deepEqual(data.groups.map(g=>g.id),['opening-plan','site-survey'],'groups follow directory order');
  const unnamed=path.join(dir,'unnamed-project');writeStandardProject(unnamed,{projectNameLine:false});assert.equal(loadStandard(unnamed).id,'unnamed-project');assert.equal(loadStandard(unnamed).name,'unnamed-project');
});

test('layout detection and the --layout override',t=>{
  const dir=directory(t),standard=path.join(dir,'standard');writeStandardProject(standard);
  assert.equal(detectLayout(standard),'standard');
  const nexusLike=path.join(dir,'nexus');fs.mkdirSync(path.join(nexusLike,'.scratch/nexus-native-refactor'),{recursive:true});fs.writeFileSync(path.join(nexusLike,'.scratch/nexus-native-refactor/map.md'),'# map\n');assert.equal(detectLayout(nexusLike),'nexus');
  const empty=path.join(dir,'empty');fs.mkdirSync(empty);assert.throws(()=>detectLayout(empty),/无法识别项目布局/);assert.throws(()=>generate({sourceRoot:empty,output:path.join(dir,'x.html')}),/无法识别项目布局/);
  fs.mkdirSync(path.join(standard,'.scratch/nexus-native-refactor'),{recursive:true});fs.writeFileSync(path.join(standard,'.scratch/nexus-native-refactor/map.md'),'# map\n');assert.throws(()=>detectLayout(standard),/--layout/);
  assert.equal(generate({sourceRoot:standard,layout:'standard',output:path.join(dir,'forced.html')}).layout,'standard');
  assert.throws(()=>generate({sourceRoot:standard,layout:'nexus',output:path.join(dir,'wrong.html')}),/ENOENT|issues/);
  assert.throws(()=>generate({sourceRoot:standard,layout:'other',output:path.join(dir,'other.html')}),/未知布局/);
  assert.equal(fs.existsSync(path.join(dir,'x.html')),false);assert.equal(fs.existsSync(path.join(dir,'wrong.html')),false);
});

test('command line accepts --layout only with --source and only known values',t=>{
  const dir=directory(t),root=path.join(dir,'p');writeStandardProject(root);const run=args=>spawnSync(process.execPath,[path.join(scripts,'generate.mjs'),...args],{encoding:'utf8',windowsHide:true});
  const ok=run(['--source',root,'--layout','standard','--output',path.join(root,'项目总览/html/决策地图.html')]);assert.equal(ok.status,0,ok.stderr);assert.equal(JSON.parse(ok.stdout).layout,'standard');
  const auto=run(['--source',root,'--output',path.join(root,'项目总览/html/决策地图.html')]);assert.equal(auto.status,0,auto.stderr);assert.equal(JSON.parse(auto.stdout).createdSnapshot,false);
  assert.notEqual(run(['--source',root,'--layout','other','--output',path.join(dir,'a.html')]).status,0);
  assert.notEqual(run(['--data',path.join(dir,'none.json'),'--layout','standard','--output',path.join(dir,'b.html')]).status,0);
  assert.equal(fs.existsSync(path.join(dir,'a.html')),false);
});

test('duplicate card ids, a missing named approval section and a closed batch without approval fail before any write',t=>{
  const dir=directory(t),root=path.join(dir,'p');writeStandardProject(root);const before=tree(root),output=path.join(root,'项目总览/html/决策地图.html');
  const duplicate=path.join(root,'专题工作/开放安排/决策卡/01-重复.md');fs.copyFileSync(path.join(root,'专题工作/场地与噪声/决策卡/01-谁会使用.md'),duplicate);
  assert.throws(()=>generate({sourceRoot:root,output}),/卡 ID 重复：01/);fs.rmSync(duplicate);
  const card=path.join(root,'专题工作/场地与噪声/决策卡/01-谁会使用.md'),original=fs.readFileSync(card,'utf8');
  fs.writeFileSync(card,original.replace('Batch section: 用户批准','Batch section: 不存在的段落'));assert.throws(()=>generate({sourceRoot:root,output}),/Batch section 指向的段落不存在/);
  fs.writeFileSync(card,original.replace('Batch section: 用户批准\n','').replace('## 用户批准','## 备注'));assert.throws(()=>generate({sourceRoot:root,output}),/本批结论无法从原卡定位: 01/);
  fs.writeFileSync(card,original);assert.deepEqual(tree(root),before);
  const map=path.join(root,'项目总览/md/决策地图.md');fs.writeFileSync(map,fs.readFileSync(map,'utf8').replace('Batch status: 已收敛','Batch status: 讨论中'));
  fs.writeFileSync(card,original.replace('Batch section: 用户批准\n','').replace('## 用户批准','## 备注'));
  const pending=generate({sourceRoot:root,output});assert.equal(pending.createdSnapshot,true);assert.equal(datasetFrom(fs.readFileSync(output,'utf8')).batch.closed,false);
});

// Runs the generated page script against the same stubbed DOM integration.test.mjs uses and returns the rendered #app HTML for one hash fragment.
function renderInPage(html,fragment){
  const script=html.match(/<script>([\s\S]*?)<\/script>/)[1],app={innerHTML:''},location={hash:'#'+fragment,href:'https://example.invalid/#'+fragment};
  const json=id=>({textContent:html.match(new RegExp('<script type="application/json" id="'+id+'">([\\s\\S]*?)</script>'))[1]}),dataset=json('dataset'),bundle=json('bundle');
  const context={URLSearchParams,console,location,history:{state:null,replaceState(state){this.state=state;}},document:{getElementById:id=>id==='dataset'?dataset:id==='bundle'?bundle:id==='app'?app:null,documentElement:{dataset:{theme:'dark',preset:'blueprint'}},body:{classList:{toggle(){}}},querySelectorAll:()=>[],addEventListener(){}},window:{addEventListener(){}},localStorage:{getItem:()=>null},requestAnimationFrame(){},setTimeout(){},clearTimeout(){}};
  vm.runInNewContext(script,context);return app.innerHTML;
}

test('two approved cards with identical approval wording keep their own topic line and heading on the overview (NEXUS cards 12 and 16 both read “确认”)',t=>{
  const root=path.join(directory(t),'同词项目');writeStandardProject(root);
  const site=path.join(root,'专题工作/场地与噪声/决策卡/01-谁会使用.md'),opening=path.join(root,'专题工作/开放安排/决策卡/03-开放时段.md'),map=path.join(root,'项目总览/md/决策地图.md');
  const rewrite=(file,from,to)=>{const text=fs.readFileSync(file,'utf8');assert.ok(text.includes(from),'fixture text missing: '+from);fs.writeFileSync(file,text.replace(from,to));};
  rewrite(site,'## 用户批准\n选择周边居民为主要使用者（示例）。','## 用户批准\n用户对上节明确选择：**“确认”**。');
  rewrite(opening,'## 已确认的开放原则\n明确选择：**“工作日晚间开放（示例）”**','## 已确认的开放原则\n用户对上节明确选择：**“确认”**。');
  rewrite(map,'Batch decisions: 01','Batch decisions: 01, 03');
  const output=path.join(root,'项目总览/html/决策地图.html'),receipt=generate({sourceRoot:root,output});
  assert.deepEqual(receipt.batchIds,['01','03']);
  const html=fs.readFileSync(output,'utf8'),byId=Object.fromEntries(datasetFrom(html).cards.map(c=>[c.id,c]));
  assert.equal(byId['01'].batchChoiceShort,'确认');assert.equal(byId['03'].batchChoiceShort,'确认');
  assert.equal(byId['01'].batchTopic,'用户批准');assert.equal(byId['03'].batchTopic,'开放原则');
  const overview=renderInPage(html,'page=overview'),articles=overview.match(/<article class="outcome">[\s\S]*?<\/article>/g)||[];
  assert.equal(articles.length,2);
  assert.match(articles[0],/决策 01<\/span>[\s\S]*?<p class="scope"><strong>用户批准<\/strong><\/p><h3>确认<\/h3>/);
  assert.match(articles[1],/决策 03<\/span>[\s\S]*?<p class="scope"><strong>开放原则<\/strong><\/p><h3>确认<\/h3>/);
  for(const article of articles)assert.equal((article.match(/<p class="scope"><strong>/g)||[]).length,1,'each outcome carries exactly one topic line');
});
