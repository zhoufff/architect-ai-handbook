# 项目展示数据接口

`--data` 读取的是项目适配器生成的 JSON，不建议手工同步一份平行的当前事实。保持来源文件唯一维护；适配器输出由生成工具读取。

最小结构：

```json
{
  "id": "project-id",
  "name": "项目名称",
  "phase": "项目当前阶段",
  "date": "2026-09-13",
  "mapVersion": "v1",
  "batch": {"ids": [], "closed": false, "status": "未记录", "nextBody": "本批安排的来源原文"},
  "groups": [{"id": "context", "title": "问题主题", "ids": ["01"]}],
  "cards": [{"id": "01", "title": "原问题名称", "status": "open", "sourceId": "card-01", "type": "research", "owner": "尚未记录", "assignee": "unassigned", "stage": "项目当前阶段", "deps": [], "question": "问题原文", "summary": "有来源的导读摘要", "parts": [], "confirmed": [], "remaining": [], "known": []}],
  "sources": [{"id": "card-01", "relative": "issues/01.md", "body": "# 原问题名称\n\n问题原文"}]
}
```

所有 ID 稳定且唯一；卡片 ID 允许字母数字、下划线与短横线；主题完整覆盖每张卡一次。依赖 `deps` 指向前置卡，必须存在且无环。原卡状态当前适配 `open/resolved/claimed`，有不同状态语义的项目需明确适配，不随意改义。

`parts` 是 `{id,title,body}` 的数组；`confirmed/remaining/known` 指向原文相应段落的 id。`batch.ids` 表示本批事项范围，可以包含尚未确认的问题；概览只把具备批准原文的事项列入已确认选择。`batchChoice` 为已批准文本，`batchChoiceShort` 为不改变含义的短结论，`batchSection` 必须指向非空批准段落，`batchTopic` 说明对象；这些不是从 open 推导的。若本批声明 closed，每项选择都必须有明确批准记录，否则生成失败。

来源 `body` 必须保留原文；HTML 会由生成器重新渲染，不信任输入的 HTML。真实文件可提供 `path` 与 `hash`；`inputFiles` 是 `{path,hash}` 列表，供生成后验证来源没有变化。没有文件路径的内联来源标为作者提供的材料，不得声称校验过原始文件。

可选 `mapViews` 是 Archify 的章节 `{id,label,focus:["d01"],note}`，节点前缀 `d` 由适配器使用；最多五章。章节不是新事实。默认按主题建立导览。

生命周期三个独立可选字段：`knowledgeStatus`（unknown / assumed / supported / conflicting / review），`decisionStatus`（open / confirmed / superseded / withdrawn），`implementationStatus`（not-started / in-progress / verified / needs-recheck）。只能从明确记录提取，缺失保持缺失；不要根据 resolved 补写 verified。Nexus 卡片可由适配器读取明确的 `Knowledge:`、`Decision:`、`Implementation:` 字段；这些字段是新增可选约定，不会自动写回现有卡。

工具保存原始展示数据，比较时忽略派生 HTML、布局主题、章节与生成时间。真实正文、批准、责任、状态、依赖和来源内容变化仍产生新版本。`examples/community.json` 是明确标注的虚构六节点测试项目，可用来核查新的适配器，不能当作真实批准记录。

## 标准布局（03 项目规则模板）

`--source <项目根目录>` 对按共享规程 03 项目规则模板布局的项目直接读取原文件，不需要手工维护展示数据；`adapters/standard.mjs` 负责读取，字段解析与 Nexus 适配器一致。目录约定：

| 位置 | 用途 |
|---|---|
| `AGENTS.md` | 取“项目名称：”一行作 `name`；没有或仍是占位符时用目录名 |
| `项目总览/md/决策地图.md` | 地图文件，必须存在；`--source` 未指定 `--layout` 时凭它识别为 standard |
| `专题工作/<专题>/决策卡/NN-*.md` | 决策卡，文件名以数字编号开头；编号即卡 ID，全项目唯一，重复报错 |
| `专题工作/<专题>/专题索引.md`（或 `README.md`、`index.md`） | 可选；首个 `# ` 标题作分组标题，没有就用专题目录名 |
| `项目总览/html/决策地图.html` | 约定输出位置；回执 `决策地图.生成记录.json` 与历史 `.decision-map-history/<project-id>/` 在同级 |

标识：`id` 与分组 `id` 由名称转 slug；名称含中文等无法转成 ASCII 时用 `project-`/`topic-` 加名称哈希前 8 位，稳定且不影响历史比较（分组不进快照事实）。分组即专题目录，顺序按目录名排序。注意项目 `id` 随“项目名称”走：改项目名称就是换项目，历史目录按 `id` 分开，旧历史不会被覆盖，也不会自动接续；改名前先决定是否保留旧历史。

地图文件的字段与段落（与 Nexus 的 map.md 相同）：

```markdown
# 项目名 决策地图
更新：2026-09-16 · v1
Phase: 探索期
Batch decisions: 01, 02
Batch status: 已收敛

## Decisions so far
- [问题标题](../../专题工作/某专题/决策卡/01-问题.md)：一句导读摘要

## 当前下一步
本批安排的原文
```

`Batch status` 含“已收敛”或“已整理完成”表示本批结束，此时每张本批卡必须有批准段落。`Decisions so far` 的每行按链接文件名的编号对应卡片，冒号后的文字作该卡摘要。

决策卡的字段与段落（与 Nexus 卡相同）：

```markdown
# 问题标题
更新：2026-09-16
Status: open | resolved | claimed
Owner: 谁负责
Assignee: 承接者或 unassigned
Type: decision | research
Stage: 所处阶段
Blocked by: none 或以逗号分隔的前置卡编号
Knowledge: unknown | assumed | supported | conflicting | review   （可选）
Decision: open | confirmed | superseded | withdrawn                （可选）
Implementation: not-started | in-progress | verified | needs-recheck（可选）
Batch section: 用户批准                                             （可选，指向下方某段标题）

## Question
问题原文

## Answer 或 已确认…
结论；这类段落计入 confirmed

## 已知输入 / 含“已有证据”“有限核对”
计入 known

## 还需补充 / 要展开 / 后续节点 / 后续处理 / 尚待后续
计入 remaining

## 用户批准
批准原文
```

批准段落不写死标题：本批卡先按 `Batch section:` 指向的段落，没有该字段时取第一个标题以“已确认”开头的段落；`Batch section:` 指向不存在的段落报错。批准文本取段内 `明确选择：**“…”**`，没有就取该段第一段的纯文本。段落中的相对 Markdown 链接会把项目内的 `.md` 文件一并嵌入作来源，上限 200 份。

输出位置保护：`项目总览/md/`、每个 `决策卡/` 目录和被链接来源文件所在目录为受保护目录，生成结果、候选文件、回执、历史目录都不能落在其中，也不能等于任何输入文件，违反时整次生成拒绝且不写入。注意卡片若链接项目根目录下的文件（如 `AGENTS.md`），根目录就进入保护范围，此时需要把输出放到项目外或先调整链接。Nexus 布局沿用同一规则，受保护目录取所有输入文件所在目录。
